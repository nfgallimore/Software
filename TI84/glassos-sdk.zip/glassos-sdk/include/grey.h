/*
    grey.h :: Greyscale library header for GlassOS
    Copyright (C) 2011 Collin Eggert

    GlassOS is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    GlassOS is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

// Help IDE preprocessors parse functions
#ifndef SDCC
#define __naked
#endif

/**
 * @defgroup libgrey Greyscale rendering library
 * @brief This library lets programs use 4-shade greyscale
 * @details This library is statically linked to your program and provides
 * a greyscale callback and rendering routines.  It doesn't contain any
 * functions to draw to the buffers.  Use libgfx while changing the current
 * greybuf to choose the shade.
 * 
 * See @subpage greyscale "the greyscale example"
 * @{
 */

#ifndef SDCC
/// 0 is light and 1 is dark
unsigned int greybuf[2];
/// Do not modify this!
unsigned char mask;
/// Change this - around 180 is normal, set after grey_on()
unsigned char grey_freq;
#else
__at 0xB10E unsigned int greybuf[2]; // 0 is light, 1 is dark
__at 0xB112 unsigned char mask;
__at 0xB113 unsigned char grey_freq;
#endif

enum
{
  GREY_LIGHT,
  GREY_DARK
};
/** @example greyscale
 * <i>You should already be familure with libgfx</i>
 * 
 * GlassOS provides greyscale functionality in order to unify how
 * the greyscale is done.  You aren't forced to use it, but any
 * improvements done to the greyscale library will be available
 * for use across all programs.
 * 
 * Take this example:  You want to draw a greyscale image and a
 * label for it.  Here is the code:
 * @verbatim
#include <glassos.h>
#include <libgfx.h>
#include <grey.h>

const unsigned char pix_light[] =
{
  0b11110000,
  0b11110000,
  0b11110000,
  0b11110000,
  0b00001111,
  0b00001111,
  0b00001111,
  0b00001111
};
const unsigned char pix_dark[] =
{
  0b00001111,
  0b00001111,
  0b00001111,
  0b00001111,
  0b11110000,
  0b11110000,
  0b11110000,
  0b11110000
};

void main()
{
  // remove the buffer
  free(lcd_buffer);
  
  // greyscale init
  grey_on();
  
  // Flip
  lcd_buffer = greybuf[0];
  
  // Draw
  ion_putsprite_or(pix_light, 16,16,8);
  
  // Flip
  lcd_buffer = greybuf[1];
  
  // Draw
  ion_putsprite_or(pix_dark, 16,16,8);
  
  // And a label
  var_lcd_y = 27
  var_lcd_x = 16;
  var_lcd_size = 1;
  var_lcd_invert = 0;
  gfx_puts("Hello World!");
  
  // clear out pressed keys
  while(Key_pressed());
  // wait for key press
  while(!Key_pressed());
  
  // stop greyscale
  grey_off();
  
  // done!
  return;
}
@endverbatim
 * 
 */

/** Draws the greyscale buffers
 * 
 * @warning This should not be called manually.
 * 
 * Performs a greyscale update.  The greyscale callback handles
 * this as this function must be called at 60Hz.
 * 
 */
extern void grey_draw() __naked;
/** Rendering callback
 * 
 * @warning This should not be called manually.
 * 
 * This is the callback entry.  This function takes care of
 * the timer and renders.
 */
extern void grey_isr(void);
/** Starts greyscale rendering
 * 
 * @warning This function removes the callback, if any, and uses timer 1.
 * @warning Your program can't task switch and will run at 5/9 speed.
 * @warning This destroys lcd_buffer. Programs start with lcd_buffer malloc'd. run <i>free(lcd_buffer);</i> before calling this.
 * 
 * This function initializes the greyscale renderer and starts
 * the callback.
 */
extern void grey_on(void);
/** Shuts down the renderer.
 * 
 * @warning This function shouldn't be used to pause rendering.  Use isr_custom = 0; instead
 * @warning lcd_buffer is dirty after this.  You <b>MUST</b> run <i>lcd_buffer = malloc(12*64);</i> afterwards to draw to the LCD.
 * 
 * This function shutdowns the renderer and cleans up the memory.
 * Normal program execution resumes after this.
 */
extern void grey_off();
/**
 * @}
 */