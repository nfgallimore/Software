/*
    glasslib.h :: Defines for glasslib in GlassOS
    Copyright (C) 2011 Collin Eggert

    GlassOS is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    GlassOS is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/
/**
 * @defgroup glasslib Standard routines
 * @brief Standard functions that can be called from your program, here to save space
 * @details The functions included here are meant to save space in your program.
 * You only have to use sys_execLibf or a libcall function.  Please note that the libcall
 * functions are in the include/ directory.  You can grab one by using \#include \<printf.c\> .
 * This is because of conflicting names when linking libraries. Please see glasslib.h 
 * for details on calling functions.
 */
#define LIB_GLASSLIB 0x01

// Library Function 0
// Real Name : printf
// Params    : char*, ...
// Returns   : void
// Comments  : From stdio, put here to save space
#define LIB_GLASSLIB_PRINTF 0x00

// Library Function 1
// Real Name : sinf
// Params    : float
// Returns   : float
// Comments  : From math, put here to save space
#define LIB_GLASSLIB_SINF 0x01

// Library Function 2
// Real Name : cosf
// Params    : float
// Returns   : float
// Comments  : From math, put here to save space
#define LIB_GLASSLIB_COSF 0x02

// Library Function 3
// Real Name : tanf
// Params    : float
// Returns   : float
// Comments  : From math, put here to save space
#define LIB_GLASSLIB_TANF 0x03

// Library Function 4
// Real Name : cotf
// Params    : float
// Returns   : float
// Comments  : From math, put here to save space
#define LIB_GLASSLIB_COTF 0x04

// Library Function 5
// Real Name : sqrtf
// Params    : float
// Returns   : float
// Comments  : From math, put here to save space

#define LIB_GLASSLIB_SQRTF 0x05
// Library Function 6
// Real Name : logf
// Params    : float
// Returns   : float
// Comments  : From math, put here to save space
#define LIB_GLASSLIB_LOGF 0x06

// Library Function 7
// Real Name : log10f
// Params    : float
// Returns   : float
// Comments  : From math, put here to save space
#define LIB_GLASSLIB_LOG10F 0x07

// Library Function 8
// Real Name : fabsf
// Params    : float
// Returns   : float
// Comments  : From math, dependancy
#define LIB_GLASSLIB_FABSF 0x08

// Library Function 9
// Real Name : _fsmul
// Params    : float, float
// Returns   : float
// Comments  : Floating point numer routines
#define LIB_GLASSLIB_FSMUL 0x09

// Library Function 10
// Real Name : _fsadd
// Params    : float, float
// Returns   : float
// Comments  : Floating point numer routines
#define LIB_GLASSLIB_FSADD 0x0A

// Library Function 11
// Real Name : _fsdiv
// Params    : float, float
// Returns   : float
// Comments  : Floating point numer routines
#define LIB_GLASSLIB_FSDIV 0x0B

// Library Function 12
// Real Name : _fs2ulong
// Params    : float, float
// Returns   : float
// Comments  : Floating point numer routines
#define LIB_GLASSLIB_FS2ULONG 0x0C

// Library Function 12
// Real Name : _fs2slong
// Params    : float, float
// Returns   : float
// Comments  : Floating point numer routines
#define LIB_GLASSLIB_FS2SLONG 0x0D

// Library Function 13
// Real Name : sprintf
// Params    : char*, ...
// Returns   : void
// Comments  : stdio
#define LIB_GLASSLIB_SPRINTF 0x0E
#define LIB_GLASSLIB_VPRINTF 0x0F
#define LIB_GLASSLIB_SPRINTF_HELPER 0x10
#define LIB_GLASSLIB_SETTIMEOFDAY 0x11
#define LIB_GLASSLIB_GETTIMEOFDAY 0x12
#define LIB_GLASSLIB_FMTTIME 0x13
#define LIB_GLASSLIB_MAKETIME 0x14


