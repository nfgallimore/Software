#ifdef SDCC
#define DEFINE_AUTHOR(x) void binary_author(){__asm  .asciz x  __endasm;}
#define DEFINE_NAME(x) void binary_name(){__asm .asciz x __endasm;}
#else
#define DEFINE_AUTHOR(x)
#define DEFINE_NAME(x)
#endif