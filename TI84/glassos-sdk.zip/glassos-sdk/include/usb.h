#ifndef _USB_H
#define _USB_H

#include <sdcc-lib.h>
#include <stdio.h>
#include <stdbool.h>
//#include <stdlib.h>

#define USB_EP_IN 0x02
#define USB_EP_OUT 0b10000001

/** @page tut-usb-1 USB Stack tutorial 1 - The Stack
 * 
 * So, you may be wondering... stack?
 * 
 * First off, the USB stack is a method of buffering packets received
 * and cycling though a stack of service masks, calling their attributed
 * callbacks.  Now, this isn't the same as other USB stacks as it
 * isn't done yet. 
 * 
 * Now, why is it a nice thing?  Easryl on in GlassOS, I saw Linky.
 * Since the hardware is the same, I renamed ports for SDCC and made
 * variables memory-mapped.  And it worked.  Now, with the driver, @b you
 * are in charge of getting a USB event, @b you must receive that packet
 * of the right size, and @b you must figure out where it goes.  Also,
 * you can only have @b one program using the USB at once.  The USb stack
 * solves all of those issues.
 * 
 * When the OS boots, the USB driver initializes and adds hooks in for
 * the USB stack.  When a packet is received, the driver notifies the stack,
 * first problem solved.  The driver was patched to force packet sizes to
 * adjust to what was recieved.  This sorta solves  the second concern, but
 * it does @b not let you receive more than 28 bytes of data per packet - 
 * this is what virtual packets are for.  (Also, if you don't get all 
 * of the packet, the driver freezes and the dies, which the stack solves)
 * Each packet is sent with a 32bit service mask.  This means allows 
 * programs to access different services at the same time.  When a service
 * sends a packet, say ID 2, then the stack will search through all processes
 * and call a callback to the ones with a mask containing bit 1 set, problem
 * 3 and 4 solved.
 * 
 * The stack buffers packets and their sizes, meaning you don't have to
 * deal with the driver to get your data.  This allows programmers to
 * use their data instantly.  Go on to the next tutorial to learn how to use
 * it!
 */

//USB Memory-mapped I/O interface
//#define USB_INIT_39_ADDR ((volatile unsigned char*)0x00710039)
__sfr __at 0x39 Port_USB_39;
//#define USB_INIT_3A_ADDR ((volatile unsigned char*)0x0071003A)
__sfr __at 0x3A Port_USB_3A;
//#define USB_INIT_4A_ADDR ((volatile unsigned char*)0x0071004A)
__sfr __at 0x4A Port_USB_4A;
//#define USB_INIT_4B_ADDR ((volatile unsigned char*)0x0071004B)
__sfr __at 0x4B Port_USB_4B;
//#define USB_INIT_4C_ADDR ((volatile unsigned char*)0x0071004C)
__sfr __at 0x4C Port_USB_4C;
//#define USB_INIT_4D_ADDR ((volatile unsigned char*)0x0071004D)
__sfr __at 0x4D Port_USB_4D;
//#define USB_BASE_POWER_ADDR ((volatile unsigned char*)0x00710054)
__sfr __at 0x54 Port_USB_Base_Power;
//#define USB_INT_STATUS1_ADDR ((volatile unsigned char*)0x00710055)
__sfr __at 0x55 Port_USB_Int_Status1;
//#define USB_INT_STATUS2_ADDR ((volatile unsigned char*)0x00710056)
__sfr __at 0x56 Port_USB_Int_Status2;
//#define USB_INT_MASK_ADDR ((volatile unsigned char*)0x00710057)
__sfr __at 0x57 Port_USB_Int_Mask;
//#define USB_INT_ENABLE_ADDR ((volatile unsigned char*)0x0071005B)
__sfr __at 0x5B Port_USB_Int_Enable;
//#define USB_FUNCTION_ADDRESS_ADDR ((volatile unsigned char*)0x00710080)
__sfr __at 0x80 Port_USB_Function_Address;
//#define USB_UNKNOWN_81_ADDR ((volatile unsigned char*)0x00710081)
__sfr __at 0x81 Port_USB_81;
//#define USB_OUTGOING_DATA_SUCCESS_ADDR ((volatile unsigned char*)0x00710082)
__sfr __at 0x82 Port_USB_Outgoing_Data_Success;
//#define USB_INCOMING_DATA_READY_ADDR ((volatile unsigned char*)0x00710084)
__sfr __at 0x84 Port_USB_Incoming_Data_Ready;
//#define USB_DATA_STATUS_ADDR ((volatile unsigned char*)0x00710086)
__sfr __at 0x86 Port_USB_Data_Status;
//#define USB_DATA_OUT_EN_ADDR1 ((volatile unsigned char*)0x00710087)
__sfr __at 0x87 Port_USB_Data_Out_En1;
//#define USB_DATA_OUT_EN_ADDR2 ((volatile unsigned char*)0x00710088)
__sfr __at 0x88 Port_USB_Data_Out_En2;
//#define USB_DATA_IN_EN_ADDR1 ((volatile unsigned char*)0x00710089)
__sfr __at 0x89 Port_USB_Data_In_En1;
//#define USB_DATA_IN_EN_ADDR2 ((volatile unsigned char*)0x0071008A)
__sfr __at 0x8A Port_USB_Data_In_En2;
//#define USB_INIT_RELATED1_ADDR ((volatile unsigned char*)0x0071008B)
__sfr __at 0x8B Port_USB_Init_Related1;
//#define USB_FRAME_COUNTER_LOW_ADDR ((volatile unsigned char*)0x0071008C)
__sfr __at 0x8C Port_USB_Frame_Counter_Low;
//#define USB_FRAME_COUNTER_HIGH_ADDR ((volatile unsigned char*)0x0071008D)
__sfr __at 0x8D Port_USB_Frame_Counter_High;
//#define USB_SELECTED_ENDPOINT_ADDR ((volatile unsigned char*)0x0071008E)
__sfr __at 0x8E Port_USB_Selected_Endpoint;
//#define USB_MODE_ADDR ((volatile unsigned char*)0x0071008F)
__sfr __at 0x8F Port_USB_Mode;
//#define USB_OUTGOING_MAX_PACKET_SIZE_ADDR ((volatile unsigned char*)0x00710090)
__sfr __at 0x90 Port_USB_Outgoing_Max_Packet_Size;
//#define USB_OUTGOING_CMD_ADDR ((volatile unsigned char*)0x00710091)
__sfr __at 0x91 Port_USB_Outgoing_Cmd;
//#define USB_UNKNOWN_92_ADDR ((volatile unsigned char*)0x00710092)
__sfr __at 0x92 Port_USB_92;
__sfr __at 0x93 Port_USB_Incoming_Max_Packet_Size;
//#define USB_INCOMING_CMD_ADDR ((volatile unsigned char*)0x00710094)
__sfr __at 0x94 Port_USB_Incoming_Cmd;
__sfr __at 0x95 Port_USB_95;
//#define USB_INCOMING_DATA_COUNT_ADDR ((volatile unsigned char*)0x00710096)
__sfr __at 0x96 Port_USB_Incoming_Data_Count;
//#define USB_OUTGOING_PIPE_SETUP_ADDR ((volatile unsigned char*)0x00710098)
__sfr __at 0x98 Port_USB_Outgoing_Pipe_Setup;
//#define USB_INCOMING_PIPE_SETUP_ADDR ((volatile unsigned char*)0x0071009A)
__sfr __at 0x9A Port_USB_Incoming_Pipe_Setup;

//#define USB_ENDPOINT0_DATA_ADDR ((volatile unsigned char*)0x007100A0)
__sfr __at 0xA0 Port_USB_Endpoint0_Data;
__sfr __at 0xA2 Port_USB_Endpoint2_Data;

//USB peripheral descriptors
/*struct DeviceDescriptor
{
	short bcdUSB;
	unsigned char bDeviceClass;
	unsigned char bDeviceSubClass;
	unsigned char bDeviceProtocol;
	unsigned char bMaxPacketSize0;
	short idVendor;
	short idProduct;
	short bcdDevice;
	unsigned char iManufacturer;
	unsigned char iProduct;
	unsigned char iSerialNumber;
	unsigned char bNumConfigurations;
};*/

// typedef enum
// {
// 	Type_Isochronous = 0x10,
// 	Type_Bulk = 0x20,
// 	Type_Interrupt = 0x30
// } USB_EndpointType;

//USB peripheral callbacks
typedef void (*Handle_SetConfiguration)(void);
typedef void (*Handle_Connected)(void);
typedef void (*Handle_HubSetFeature)(int feature, int index);
typedef void (*Handle_HubClearFeature)(int feature, int index);
typedef void (*Handle_HubGetStatus)(unsigned char* data, int index);
typedef void (*Handle_SetAddress)(int address);
typedef void (*Handle_ControlOutputDone)(void);
typedef int (*Handle_UnknownControlRequest)(unsigned char bmRequestType, unsigned char bRequest, unsigned int wValue, unsigned int wIndex, unsigned int wLength);
typedef void (*Handle_IncomingData)(unsigned char readyMap);

//USB peripheral mode interface
typedef struct
{
	const unsigned char*         deviceDescriptor;
	const unsigned char*         configDescriptor;
	const unsigned char*         qualifDescriptor;
	Handle_SetConfiguration      h_setConfig;
	Handle_Connected             h_connected;
	Handle_HubSetFeature         h_hubSetFeature;
	Handle_HubClearFeature       h_hubClearFeature;
	Handle_HubGetStatus          h_hubGetStatus;
	Handle_SetAddress            h_setAddress;
	Handle_ControlOutputDone     h_controlOutputDone;
	Handle_UnknownControlRequest h_unknownControlRequest;
	Handle_IncomingData          h_incomingData;
} USBPeripheral;

//For internal driver use (should these go somewhere else?)
//INT_HANDLER OldInt3;                  //Backup of old AUTO_INT_3 interrupt vector
__at 0xC020 volatile unsigned char bMaxPacketSize0;				//used in control pipe communication
__at 0xC055 volatile const unsigned char* controlDataAddress;		//used in sending back control request responses
__at 0xC022 volatile unsigned int responseBytesRemaining;	//used in sending back control request responses
__at 0xC024 volatile int USBState;													//used in sending back control request responses
__at 0xC026 volatile int newAddressReceived;								//used in setting the address from the interrupt
__at 0xC028 volatile int wAddress;													//used in setting the address from the interrupt
__at 0xC02A volatile int bytesBuffered[0x0F];							//keeps track of buffered incoming data per pipe
__at 0xC048 volatile unsigned char incomingDataReadyMap;
__at 0xC049 volatile unsigned int rawSize;
__at 0xC04B volatile void* USB_ReceivedVirtualPacket;
__at 0xC04D volatile unsigned int USB_CurrentPacketOffset;
__at 0xC04F volatile unsigned int USB_CurrentPacketSize;
__at 0xC051 volatile unsigned short USB_CurrentPacketCommandID;
__at 0xC053 volatile USBPeripheral* peripheralInterface;   //Pointer to USB peripheral mode setup/interface information

#ifndef SDCC
#define __naked
#endif
//Basic driver functions
#ifndef USB_STOP_STRIPPING
void Driver_Initialize() __naked;
void Driver_Kill() __naked;
void Driver_SetPeripheralInterface(USBPeripheral* interface) __naked;

// Helper functions
//void* USB_alloc(unsigned int);
//USB functions
int USB_IsDataReady(unsigned char endpoint) __naked;
void USB_IndicateNotReady(unsigned char endpoint) __naked;
void USB_SendBulkData(unsigned char endpoint, unsigned char* data, unsigned int count) __naked;
void USB_KillPower() __naked;
void USB_PeripheralInitialize() __naked;
void USB_PeripheralKill() __naked;
void USB_SetFunctionAddress(int address) __naked;
void USB_FinishControlRequest() __naked;
void USB_StartControlOutput(unsigned char* address, int bytesRemaining) __naked;
void USB_SendControlData(unsigned char* data, unsigned int length) __naked;
void USB_FinishControlOutput() __naked;
int USB_SendInterruptData(unsigned char endpoint, unsigned char* data, unsigned int count) __naked;
int USB_ReceiveInterruptData(unsigned char endpoint, unsigned char* data, unsigned int count) __naked;
int USB_ReceiveBulkData(unsigned char endpoint, unsigned char* data, unsigned int count) __naked;
void USB_SetupOutgoingPipe(unsigned char endpoint, USB_EndpointType type, unsigned char maxPacketSize) __naked;
#endif
#endif
