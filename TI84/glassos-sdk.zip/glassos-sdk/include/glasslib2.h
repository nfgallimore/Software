/*
    glasslib2.h :: Defines for glasslib2 in GlassOS
    Copyright (C) 2011 Collin Eggert

    GlassOS is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    GlassOS is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

/**
 * @defgroup glasslib2 More math routines
 * @brief Extended math routines that can be called
 * @details The functions included here are meant to save space in your program.
 * You only have to use sys_execLibf or a libcall function.  Please note that the libcall
 * functions are in the include/ directory.  You can grab one by using \#include \<powf.c\> .
 * This is because of conflicting names when linking libraries. Please see glasslib2.h 
 * for details on calling functions.
 */
#define LIB_GLASSLIB2 0x02

// Library Function 0
// Real Name : asinf
// Params    : float
// Returns   : float
// Comments  : From math, put here to save space
#define LIB_GLASSLIB2_ASINF 0x00

// Library Function 1
// Real Name : acosf
// Params    : float
// Returns   : float
// Comments  : From math, put here to save space
#define LIB_GLASSLIB2_ACOSF 0x01

// Library Function 2
// Real Name : atanf
// Params    : float
// Returns   : float
// Comments  : From math, put here to save space
#define LIB_GLASSLIB2_ATANF 0x02
#define LIB_GLASSLIB2_EXPF 0x03
#define LIB_GLASSLIB2_POWF 0x04

#ifdef GLASSLIB2_IEEE
float _powf(const float x, const float y)
{
  return sys_execLibf(LIB_GLASSLIB2,LIB_GLASSLIB2_POWF,x,y);
}
#endif
