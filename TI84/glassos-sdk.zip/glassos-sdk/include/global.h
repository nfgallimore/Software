/*
    global.h :: Global defines for sdcc and variables in GlassOS
    Copyright (C) 2011 Collin Eggert

    GlassOS is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    GlassOS is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/
// Everything looks here for stuff
#ifndef GLOBAL_H
#define GLOBAL_H
#include <sdcc-lib.h>
#include <stdio.h>
#include <stdbool.h>
#include <math.h>
#include <string.h>
#include <ctype.h>
#include "keyboard.h"
#define BYTE unsigned char 
#define byte BYTE

// PORT NAMES
#ifndef SDCC
// Help IDE preprocessors
unsigned char Port_Link;
unsigned char Port_Keyboard;
unsigned char Port_Status;
unsigned char Port_Interrupt_Mask;
unsigned char Port_Mem_Map;
unsigned char Port_Batt;
unsigned char Port_Interrupt_Status; // Same as above, just naming it
unsigned char Port_Mem_B3;
unsigned char Port_Mem_B1;
unsigned char Port_Mem_B2;
unsigned char Port_LCD_Command;
unsigned char Port_LCD_Data;
unsigned char Port_Flash_Protect;
unsigned char Port_ASIC_Version;
unsigned char Port_CPU_Scale;
unsigned char Port_Flash_Type;
unsigned char Port_Flash_Protection;
unsigned char Port_Ram_Execution_Lower_Limit;
unsigned char Port_Ram_Execution_Upper_Limit;
// Clock
unsigned char Port_Clock_Control;
unsigned char Port_Clock_Set_0;
unsigned char Port_Clock_Set_1;
unsigned char Port_Clock_Set_2;
unsigned char Port_Clock_Set_3;
unsigned char Port_Clock_Read_0;
unsigned char Port_Clock_Read_1;
unsigned char Port_Clock_Read_2;
unsigned char Port_Clock_Read_3;
// USB
unsigned char Port_USB_Interrupt;
unsigned char Port_USB_Mask;
unsigned char Port_USB_Line_Event;
unsigned char Port_USB_Line_Event_Mask;
unsigned char Port_USB_Outgoing_Pipe;
// Timers
unsigned char Port_Timer_1_OnOff;
unsigned char Port_Timer_1_Loop;
unsigned char Port_Timer_1_Counter;
unsigned char Port_Timer_2_OnOff;
unsigned char Port_Timer_2_Loop;
unsigned char Port_Timer_2_Counter;
unsigned char Port_Timer_3_OnOff;
unsigned char Port_Timer_3_Loop;
unsigned char Port_Timer_3_Counter;
#else
__sfr __at 0x00 Port_Link;
__sfr __at 0x01 Port_Keyboard;
__sfr __at 0x02 Port_Status;
__sfr __at 0x03 Port_Interrupt_Mask;
__sfr __at 0x04 Port_Mem_Map;
__sfr __at 0x04 Port_Batt;
__sfr __at 0x04 Port_Interrupt_Status; // Same as above, just naming it
__sfr __at 0x05 Port_Mem_B3;
__sfr __at 0x06 Port_Mem_B1;
__sfr __at 0x07 Port_Mem_B2;
__sfr __at 0x10 Port_LCD_Command;
__sfr __at 0x11 Port_LCD_Data;
__sfr __at 0x14 Port_Flash_Protect;
__sfr __at 0x14 Port_Flash_Protection;
__sfr __at 0x15 Port_ASIC_Version;
__sfr __at 0x20 Port_CPU_Scale;
__sfr __at 0x21 Port_Flash_Type;
__sfr __at 0x25 Port_Ram_Execution_Lower_Limit;
__sfr __at 0x26 Port_Ram_Execution_Upper_Limit;
// Clock
__sfr __at 0x40 Port_Clock_Control;
__sfr __at 0x41 Port_Clock_Set_0;
__sfr __at 0x42 Port_Clock_Set_1;
__sfr __at 0x43 Port_Clock_Set_2;
__sfr __at 0x44 Port_Clock_Set_3;
__sfr __at 0x45 Port_Clock_Read_0;
__sfr __at 0x46 Port_Clock_Read_1;
__sfr __at 0x47 Port_Clock_Read_2;
__sfr __at 0x48 Port_Clock_Read_3;
// USB
__sfr __at 0x55 Port_USB_Interrupt;
__sfr __at 0x56 Port_USB_Line_Event;
__sfr __at 0x57 Port_USB_Line_Event_Mask;
__sfr __at 0x5B Port_USB_Mask;
__sfr __at 0xa1 Port_USB_Outgoing_Pipe;
// Timers
__sfr __at 0x30 Port_Timer_1_OnOff;
__sfr __at 0x31 Port_Timer_1_Loop;
__sfr __at 0x32 Port_Timer_1_Counter;
__sfr __at 0x33 Port_Timer_2_OnOff;
__sfr __at 0x34 Port_Timer_2_Loop;
__sfr __at 0x35 Port_Timer_2_Counter;
__sfr __at 0x36 Port_Timer_3_OnOff;
__sfr __at 0x37 Port_Timer_3_Loop;
__sfr __at 0x38 Port_Timer_3_Counter;
#endif

#define MAX_INCOMING_PACKET 0x20
#define ISSET(x,y) (!(x & ~y))


#define setHook(x) \
  isr_custom = 0; \
  isr_custom_location = (x); \
  isr_custom_page = Port_Mem_B1; \
  isr_custom = 1

  typedef struct 
  {
    byte d,c,b,a;
  } clock_struct;
  
// This is the multi-tasking part of the OS
// This data must be carefully gathered from the ISR
// The data is pushed onto the stack.  I have to use asm -_-
// Nonetheless, I still need C to place the stuff 
// in the right place. :-)
typedef enum
{
  RUNNING,
  NEW,
  ZOMBIE,
  STOPPED,
  NONE
} pStatus;

typedef struct
{
  byte uuid;
  byte bankA,bankB;
  byte parent;
  pStatus status;
} pInfo;
typedef struct
{
  long serviceMask;
  bool UVP;
  byte bankA, bankB;
  void (*callback)(byte);
} USBStack;
typedef struct
{
  long service;
  unsigned char data[28];
} usb_pak;

typedef struct _process_name process_name;
struct _process_name
{
  char icon[8];
  char name[15];
};


// Global data
#ifdef SDCC
__at 0xB100 unsigned char* lcd_buffer;
__at 0xBB10 volatile unsigned char var_lcd_x;
__at 0xBB11 volatile unsigned char var_lcd_y;
__at 0xBB12 volatile unsigned char var_lcd_invert;
__at 0xBB13 volatile unsigned char var_lcd_size; // Font size, 1 = big, 0 = small
__at 0xBB14 unsigned int var_sys_lib_index; // Bigger boom than C4!
__at 0xBB16 byte var_lcd_custom_scroll;
// 0xBB17 is used
__at 0xBB18 bool var_buffered_draw;
__at 0xBB19 unsigned char var_UVP_state;
__at 0xBB1a unsigned int var_UVP_buffer_size;
__at 0xBB1c byte var_lcd_scroll_x1;
__at 0xBB1d byte var_lcd_scroll_x2;
__at 0xBB1e byte var_lcd_scroll_y1;
__at 0xBB1f byte var_lcd_scroll_y2;
__at 0xBB20 byte var_key_get[14];
__at 0xBB2E byte var_sys_lib_stack[8*5]; // Only 3 deep, this can be changed!!! 
// AVAILABLE: 0xBB46-0xBB48
__at 0xBB56 byte var_key_mode;
__at 0xBB57 unsigned char *var_UVP_buffer;
__at 0xBB59 unsigned int var_UVP_vp_size;
__at 0xBB5b unsigned char *var_UVP_buffer_moving;
__at 0xBB5d unsigned long var_UVP_mask;
// Above should be placed in private program RAM so you can multitask
// when using libraries D-:
__at 0x7B14 unsigned int prog_lib_index; // Bigger boom than C4!
__at 0x7B10 volatile unsigned char prog_var_start;
__at 0x7B20 byte prog_key_get[14];
__at 0x4000 byte ram_test_target;
// From 0xBB00 to 0xBB45
// --------------------------------

// ISR Settings
#define isr_master isr_is_off
__at 0xC000 byte isr_real_mode; // Set this by isr_real_mode = 0xC0, or format as heap
__at 0xC010 bool isr_powersave;
__at 0xC011 bool isr_usb;
__at 0xC012 bool isr_tasking;
__at 0xBB17 bool isr_clock_int; // Questionable
__at 0xC014 bool isr_launch;
__at 0xC015 bool isr_is_off;
__at 0xC016 bool isr_custom;
__at 0xC017 byte isr_custom_page;
__at 0xC018 void (*isr_custom_location)(void);
__at 0xC01A byte var_sys_isEmulator;
// Careful here...
__at 0xC100 pInfo var_processes[7];
__at (0xC124) unsigned char var_max_processes;
__at 0xC125 volatile unsigned int isr_random;
__at 0xC127 process_name var_process_names[7]; // end at 0xC1C1
__at 0xC1C1 USBStack usb_stack[7]; // all 7, ends at 0xC200
__at 0xC200 unsigned char usb_pak_data[32];
__at 0xC220 unsigned char usb_pak_size; // ends at 0xC21A
__at 0xC221 unsigned char var_usb_connected;

__at 0xC091 char var_sys_currentThread;

__at 0x7FFa unsigned int prog_return_stack;
__at 0x7FFc int prog_argc_stack;
__at 0x7FFe char** prog_argv_stack;

__at 0xBB50 unsigned int prog_registers[8];
  
__at 0xC092 unsigned int var_registers[8];
__at 0xC092 unsigned int  var_sys_isr_PC;//0,1
__at 0xC094 unsigned int  var_sys_isr_af;//2,3
__at 0xC096 unsigned int  var_sys_isr_bc;//4,5
__at 0xC098 unsigned int  var_sys_isr_de;//6,7
__at 0xC09A unsigned int  var_sys_isr_hl;//8,9
__at 0xC09C unsigned int  var_sys_isr_iy;//10,11
__at 0xC09E unsigned int  var_sys_isr_ix;//12,13
__at 0xC0A0 unsigned int  var_sys_isr_SP;//14,15

#else
unsigned char var_UVP_state;
unsigned char *var_UVP_buffer, *var_UVP_buffer_moving;
unsigned int var_UVP_buffer_size, var_UVP_vp_size;
unsigned long var_UVP_mask;
unsigned char* lcd_buffer;
volatile unsigned char var_lcd_x;
volatile unsigned char var_lcd_y;
volatile unsigned char var_lcd_invert;
volatile unsigned char var_lcd_size; 
unsigned int var_sys_lib_index;
byte var_lcd_custom_scroll;
bool var_buffered_draw;
byte var_lcd_scroll_x1;
byte var_lcd_scroll_x2;
byte var_lcd_scroll_y1;
byte var_lcd_scroll_y2;
byte var_key_get[14];
byte var_sys_lib_stack[24];
byte var_key_mode;
unsigned int prog_lib_index; 
volatile unsigned char prog_var_start;
byte prog_key_get[14];
byte ram_test_target;
#define isr_master isr_is_off
byte isr_real_mode; 
bool isr_powersave;
bool isr_usb;
bool isr_tasking;
bool isr_clock_int; 
bool isr_launch;
bool isr_is_off;
bool isr_custom;
byte isr_custom_page;
void (*isr_custom_location)(void);
byte var_sys_isEmulator;
pInfo var_processes[7];
unsigned char var_max_processes;
volatile unsigned int isr_random;
process_name var_process_names[7];
USBStack usb_stack[7]; 
unsigned char usb_pak_data[32];
unsigned char usb_pak_size; 
unsigned char var_usb_connected;
char var_sys_currentThread;
unsigned int prog_return_stack;
int prog_argc_stack;
char** prog_argv_stack;
unsigned int prog_registers[8];
unsigned int var_registers[8];
unsigned int  var_sys_isr_PC;
unsigned int  var_sys_isr_af;
unsigned int  var_sys_isr_bc;
unsigned int  var_sys_isr_de;
unsigned int  var_sys_isr_hl;
unsigned int  var_sys_isr_iy;
unsigned int  var_sys_isr_ix;
unsigned int  var_sys_isr_SP;

#endif

#define LCD_X_MAX 95 // starts at 0
#define LCD_Y_MAX 63

// SP is highly touchy... I need to save the entire stack.
// When the ISR starts, 5 things are on the stack: EVERYTHING!
// SDCC uses ix for regular code and iy for ISR code (how nice!)
// When it leaves, I need to restore the stack...

// Heap from 0xD000 to 0xE000

#define abs(x) \
	((x) ? (x) : (-(x)))
#define min(x,y) ((x) > (y) ? (y) : (x))
#ifdef SDCC
#define DI() __asm  di  __endasm
#define EI() __asm  ei  __endasm
#define HALT() __asm  halt  __endasm
#else
#define DI()
#define EI()
#define HALT()
#endif
/** Allocates memory in user ram.
 * 
 * This function allocates memory in user ram.  This can only be called when in a user program or library.
 * 
 * @param s The length in bytes to alloc
 * @returns A pointer to allocated memory
 */
#define malloc(s) heap_malloc((s), MEM_HEAP_START)

/** Frees memory
 * 
 * This can be called for both user and global malloc'd pointers.
 * 
 * @param p Pointer to malloc'd data
 */
#define free(p) heap_free((p))

#define malloc_shared(s) heap_malloc((s), 0xD000)
#define free_shared(p) heap_free((p))

#define CHAR_FAR_BIG 0x000B

typedef struct
{
  byte id;
  unsigned int count;
} TimerIndex; // size=3
typedef enum
{
	Type_Isochronous = 0x10,
	Type_Bulk = 0x20,
	Type_Interrupt = 0x30
} USB_EndpointType;
/*

Thanks to BrandonW, GlassOS has to jump through hoops!!!
Even more thanks for work done to get USB working :-D
  Filesystem must be validated on os start
  otherwise, a format is needed.
  In order to go back to tios, you need to deformat the flash
    ? I wonder if flash drives could be formatted using my file system?
  As I am told, the OS starts at 0x53.  Port 07 will 0 if the OS is fresh.
  
Lets talk about libs
libs are, as in linux, named libXXX.so

Libs are divided into 2 parts:
* jump table
* code

There is NO crt0 for libs (nor in bin's).
Here is a quick library:

// -->
// libTest.so

void JumpTable(void) __naked  // CASE-SENSATIVE
{
  __asm
  .dw #_test  // Just put #_ and the function name
  __endasm;
}

void test()
{
  printf("1");
}
// <--

You can call it from a client program by using:

  sys_execLib(Page, JumpID);
  
This will locate the lib in the fs, halt the current process, DI,
save all of the registers, and jump to the library's crt0, which uses
the jump table.  When it returns, the OS will restore the
registers, EI, and return.

If you have a function like:  void something(byte a, int b);
You can call it like:  sys_execLib(Page, JumpID, a, b);


Now, the file system...

XX: The filesystem is a regular heap.  There the items in the heap
XX: are called nodes.  There are 2 types of nodes: the data node and the 
XX: folder node.  This is the layout of the d_node:

The filesystem will consist of the storgage section, the swap pages, and the node collection.
The memory will use Heap1 and the fs will use Heap2.  Heap alloc's store (ya know...) infromation
on the alloc.  The Heap2 has flags and other rules applied to it for use ona flash chip.  It should
work very quickly.  Because the flash CAN ONLY BE 0ed, INIT WILL BE VERY DIFFERENT!!!  The Heap2
allocates will be oned out so you can dynamically edit them.  Rules:
  Pointer to the next alloc will be FFFF.  This means that this is the last one.  Prev with
    0000 says that it is the root node.  FS uses this as the / folder.

IINNNNN...
  N = filename (Unlimited)
  I = ID of data (2 bytes)

    The filename is unlimited in length.  The main problem with this
      is that the filesystem has only 16K for nodes.  If you fill it up,
      then you will get memory full errors.  Although the filename
      "technically" isn't limited, it realistically is.  The sys_execLib
      passes args in the global memory (4K with some used).  All in all,
      the end of the filename is shown with a 0, or '\0'.
    The ID is used to find the data node in the fs.  The fs_alloc for files
      requires an ID.  The entire fs is searched for this ID and that's how
      files are found.  
      
      
The f_node is as follows:

NNNN...
  N = Folder name (Unlimited)
  
    Folder name, see the data node's stuff.
      
SCRIBBLE NOTES: (yeah, in real-time)
  When switching tasks, the stack MUST be copied.  I am thinking
    that reserving 1K of program memory for it's stack.  Oh, wait...
    LOL, just as I am typing this at 12:02 at night, I just though of this:
      When a program starts, the SP will be set at the end of program memory.
      It will be loaded with the return address and passed params (future).
      This way, if the SP invades the Heap and the ISR detects it, it will throw an error.
      That way, the program can smoothly change to other tasks.
	0x4000 - 0x7BFF = Heap
	0x7C00 - 0x7FFF = Stack
  Programs will obey the usual C params.  You will start processes
    like "graph.bin -p points.tmp --image -o plot.pic".  You can see where
    I am going... They will be put onto the stack like any other variable,
    except the entire argv will be copied, not a pointer.  Why? The stack
    is BIG!!!  I can make a crt0 that would auto-alloc the params... Wait,
    again, dam! Now at 12:11am, the OS is the only thing that starts the programs...
    Change bank 1, setup pa heap, do the first malloc (ptr is always @ 0x0000),
    drop the params, done!  No special anything.  If the program doesn't
    even use the params, it wouldn't know!
  OS will contain a built-in library (16K limit is hard).
    No filename as it will not be in the fs (no deletion).
    There is page 7C.  This can be used, but it isn't a library.
    Pages 1, 2, and 3 are all libraries (16K each).  So, the 
    OS has 16K for the base OS, page 0, and 64K for more libs.
    AND you can load even more libs into the filesystem!
  Naming convention:
    *.so  = libraries
    *.bin = executables
    *.txt = plain text
    *.pic = RLE images, in 2 and 4 shade. (8 shade anyone?)
    *.mod = MOD music files... This will be good
    *.wav = WAV files, sloppy, big, ugly
    *.mid = MIDI files, simple stuff
    *.plc = Program Launcher Config file, used by Launch to display programs
    *.csv = comma sep... wait, where have you been living?!?
    *.cfg = general configs for programs
    *.thtm*, *.htm* = simple formatted documents
	    I will provide a reader for it, it will be basic HTML formatting.
	    A widget will be made to support it.
  GUI:
    This will be the one way that GlassOS will stand out from the rest!
    Everything is drawn individually.
    Batch drawing from malloc array of mallocs?
    Basic types of widgets:
      desk - encapsulates all widgets, event handler, batch?
      menu bar - 5 functions, drop-down, 1 level for now, at the TOP
      popup menu - Required by menu bar.  You can use it for popups, right-clicks (?), etc.
      textentry - single line, trimmed
      dialog - simple dialog, encapsulates children, event handler (inher.)
      image - just a simple 8x8 image, invertable
      listview - single line, scrollable left<->right, up<->down, checkable
      button - regular button
      label - just text
    More advanced:
      statusbar - a label at the bottom, with a box around it, lol
	This is NOT attached to a container.  It also shows the 
	flash write cursor and the busy cursor.  Interrupt driven!
      animation - animated 8x8 image
      check box - checkable box
      radio - yeah... you can guess
      textinput - multiline input, scrollable in 2 or 4 ways
      raw - lcd buffer, instead of writing directly to the LCD
      treeview - tree (filesystem, etc)
      table - row/col. layout, scrollable in a spreadsheet way
    Totally advanced:
      richtextinput - in thtml format, only scrolls up<->down
      grayscaleimage - image in grayscale
      3d - a 3d viewport that uses lib3d
      customview - each entry is manually drawn, then given to the widget
  Filesystem
    The file system can't erase stuff easily...
      Deletion is done by setting a flag.  You can then 'recover' the file with special progs.
	The fs commands will NOT support deleted files
    Other flags for read only, folder, etc. exist
    The filesystem HAS to collect garbage eventually...  So, why not collect when you turn it off?
      The system can turn off, check the fs for erased files, and begin defragmenting everything.
      This will ONLY WORK WITH NO PROGRAMS RUNNING! Why?  Just in case a program wants to hack...
      The OS will create a Heap2 in the ram an copy files from the ROM pages.  When the 
      RAM can't take the next data alloc, it copies itself to the 'swap' page, and repeats
      for all 4 pages.  Then, it erases the sector and sets up the fs on the pages.
	
    Calling main(int, char**) sets up the stack as this: r|r|a|a|b|b
      This MUST be copied to program's stack, with r|r returning to ROM 0.
*/
// chars wide
#define POPUP_MENU_WIDTH 8

#ifndef GUI_INC
#define GUI_INC

// heap declares
typedef struct _MEMHEADER MEMHEADER;

struct _MEMHEADER
{
    MEMHEADER *    next;
    MEMHEADER *    prev;
    unsigned int   len;
    unsigned char  mem;
};


#define HEAP2_SIZE (sizeof(heap2_n) - sizeof(char))

typedef struct HEAP2_N heap2_n;
struct HEAP2_N
{
    heap2_n *next;
    heap2_n *prev;
    unsigned int len;
    byte flags; // You know...
    unsigned int ID; // Finding stuff from index to flash
    unsigned int parent; // Folders, etc.
    byte frag;
    unsigned char mem;
    
};
typedef enum
{
  FILE_OPEN = 0,
  FILE_INDEX_NO_SPACE = 1,
  FILE_NO_MEMORY = 2,
  FILE_BAD_FILENAME = 3,
  FILE_BAD_DIR = 4,
  FILE_CLOSED = 5
};
typedef enum
{
  FLAG_DELETED = 		0b11111110,
  FLAG_FOLDER  = 		0b11111101,
  FLAG_PROGRAM = 		0b11111011,
  FLAG_LIBRARY = 		0b11110111,
  FLAG_VIRTUAL_PROGRAM = 	0b11101011,
  FLAG_VIRTUAL_LIBRARY = 	0b11100111
};

#define FS_FLAG_DELETE FLAG_DELETED
  
typedef struct _FILE FILE;
struct _FILE
{
  byte page; // page that the CURRENT heap2_n is at
  heap2_n* node; // w/e
  unsigned int offset; // &(node->mem) + offset
  unsigned int length;
  byte errno;
  byte eof;
  byte mode;// nonzero if EOF
};
#define U_INT unsigned int
typedef enum 
{
  DIRENT_FILE = 1,
  DIRENT_FOLDER,
  DIRENT_VFS
} dirent_t;

typedef struct _dirent dirent;
struct _dirent
{
  char *name;
  dirent_t type;
};

typedef struct _DIR DIR;
struct _DIR
{
  unsigned int parentID;
  unsigned int currentID;
  dirent *de;
  unsigned int VFS_i1;
  byte VFS_b1,VFS_b2;
};

  
#endif

#define HEADER_SIZE (sizeof(MEMHEADER)-sizeof(char))
#define LCD_off() (Port_LCD_Command = 0x02)
#define LCD_on() (Port_LCD_Command = 0x04)
#define LCD_xgetX() (var_lcd_x)
#define LCD_xgetY() (var_lcd_y)
#define LCD_xsetX(x) (var_lcd_x = (x))
#define LCD_xsetY(x) (var_lcd_y = (x))
#define Key_reset() Key_setGroup(KR_NULL)

// sys stuff
#define MEM_START      0x08
#define MEM_ROM_END    0x69
#define MEM_RAM_START  0x80
#define MEM_MAX        0x87

#define sys_cpuFast() Port_CPU_Scale = 0x01
#define sys_cpuSlow() Port_CPU_Scale = 0x00

#define MEM_PROGRAM_START 0x4000
#define MEM_HEAP_START 0x8000
#define MEM_EXTRA_START 0xC000

/*
#define RAM_0 0x80
#define RAM_1 0x81
#define RAM_2 0x82
#define RAM_3 0x83
#define RAM_4 0x84
#define RAM_5 0x85
#define RAM_6 0x86
#define RAM_7 0x87
*/
enum
{
  RAM_0 = 0x80,
  RAM_1 = 0x81,
  RAM_2 = 0x82,
  RAM_3 = 0x83,
  RAM_4 = 0x84,
  RAM_5 = 0x85,
  RAM_6 = 0x86,
  RAM_7 = 0x87
};

// Usable ROM:
// 00 to 69
// Remember to unformat the flash before sending tios
// The first byte of a sector for swap must be 0xFE
// The rest as 0xFF
// 70 to 79 and 7B to 7D are OK for OS stuff...
// On the fs lifecycle:
/*
 * Do an integrity check
 * If it fails, format the flash
 * If the user says no, then exit the OS
 * Else, format it and go!
 * Once done, unformat the flash for tios, then exit
 */

/*
 * ROM page layout:
 * 
 * 0x00 - all.c
 * 0x01 - glasslib.c
 * 0x02 - glasslib2.c
 * 0x03 - gui.c
 * 0x04 - glasslib3.c
 * 	contains overflow stuff from ROM 0
 */

/*
const unsigned char pic_usb[32] =
{
    0x01, 0x00, 0x03, 0x80,
    0x01, 0x00, 0x01, 0x70,
    0x01, 0x70, 0x01, 0x20,
    0x09, 0xc0, 0x1d, 0x00,
    0x09, 0x00, 0x09, 0x00,
    0x07, 0x00, 0x01, 0x00,
    0x03, 0x80, 0x07, 0xc0,
    0x03, 0x80, 0x01, 0x00
};
*/

typedef struct _GUI_Container GUI_Container;
typedef struct _GUI_Widget GUI_Widget;
typedef struct _GUI_Return GUI_Return;
typedef enum _GUI_Container_Type GUI_Container_Type;
typedef enum _GUI_Widget_Type GUI_Widget_Type;
typedef enum _GUI_Key GUI_Key;
struct _GUI_Container
{
    GUI_Container_Type type; // The type of container
    byte x1,y1,x2,y2; // The bounds of it

    bool enabled; // For desktop only. Will it show?
    bool closed;  // If true, then the high-high functions will exit
    bool draw_child_containers; // You can guess
    bool forceDraw;

    GUI_Widget* widgets[20];  // Not too many.  This tells the ___-high functions
    // what widgets to do actions on. (deletion is easier, too)
    GUI_Container* container; // Only one.  Don't barf on the screen, please.

    char* title; // Title for windows
    byte selected; // The index number of the selected widget
    byte prev_selected; // The index number of the selected widget

    // Internal-ish
    // Desktop only
    GUI_Widget* menubar;  // Easy access for high-level stuff (req.)
    GUI_Widget* statusbar; // Only for desktop!
    void (*callback)(void);

};

struct _GUI_Widget
{
    GUI_Widget_Type type; // The type of widget
    byte x1,y1,x2,y2; // The bounds of it, or the position/size

    bool enabled; // Can the widget be activated/acted on?
    bool show; // Do I need to explain?

    // These vary by the widget
    char *data1;
    byte data2;
    bool data3;
    GUI_Widget *data4[20];

    bool changed;

    // The lovely callback function. Passes:
    // 	Action, widget, parent container.
    void (*callback)(GUI_Key,GUI_Container*,GUI_Widget*);


};

typedef unsigned int GUI_Serial_Data;

struct _GUI_Return
{
  GUI_Widget *w;
  GUI_Container *c;
  GUI_Key k;
};

enum _GUI_Container_Type
{
    Desktop,
    Window
};


enum _GUI_Widget_Type
{
    Button,
    Label,
    Checkbox,
    Radio,
    Popup, // This one is here just because... It isn't selectable, nor a widget...
    Menubar, // Same here
    Image,
    Textbox
};

enum _GUI_Key
{
    Up,
    Down,
    Left,
    Right,
    Enter,
    F1,
    Clear,
    Delete,
    Other
};
typedef struct
{
  byte ID;
  void* callback;
} serial_cb;
typedef struct
{
  byte ID;
  char* text;
} serial_text;
typedef struct
{
  byte id;
  GUI_Widget_Type type;
  byte parent;
  byte x1, y1, x2, y2, textID, parentID, callbackID, extra1, extra2;
} serial_widget;

#define max(a,b) ((a) < (b) ? (b) : (a))
#endif
