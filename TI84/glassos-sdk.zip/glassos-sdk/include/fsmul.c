#define GLASSLIB_EXTERN
#include "glasslib.h"

float __fsmul (float a1, float a2) __naked
{
  a1;a2;
    //return sys_execLibf(LIB_GLASSLIB, LIB_GLASSLIB_FSMUL, a1, a2);
  __asm
  rst #0x18
  .db #1
  .dw #9
  ret
  __endasm;
}
