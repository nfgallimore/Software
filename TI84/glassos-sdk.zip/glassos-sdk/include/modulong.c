unsigned long _modulong (unsigned long a, unsigned long b) __naked
{
  a;b;
  __asm
    rst #0x18
    .db #2
    .dw #9
    ret
  __endasm;
}