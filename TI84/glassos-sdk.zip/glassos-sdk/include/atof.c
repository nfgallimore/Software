float atof(const char * s) __naked
{
  s;
  __asm
    rst #0x18
    .db #2
    .dw #8
    ret
  __endasm;
}