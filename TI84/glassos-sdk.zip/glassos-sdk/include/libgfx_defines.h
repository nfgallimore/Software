
__at 0xb003 unsigned char clip_mask;
typedef struct
{
  unsigned char *sprite, **sprite_map;
  unsigned char x,y,width,height;
} gfx_tilemap_data;

typedef struct
{
  unsigned char *sprite, *mask;
  unsigned char height;
  unsigned char x,y;
} gfx_maskedsprite_data;

typedef struct
{
  gfx_maskedsprite_data sprite;
  unsigned char **animation_sprite_list;
  unsigned char **animation_mask_list;
  unsigned char keyframe, maxkeyframes;
} gfx_animatedsprite_data;
