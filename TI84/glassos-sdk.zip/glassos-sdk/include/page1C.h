// Created by autoheader.php

#ifndef H_page1C
#define H_page1C
#include "global.h"

#define FUNCTION_ram_test_target 0x4000
#define FUNCTION_prog_var_start 0x7B10
#define FUNCTION_prog_lib_index 0x7B14
#define FUNCTION_prog_key_get 0x7B20
#define FUNCTION_prog_return_stack 0x7FFA
#define FUNCTION_prog_argc_stack 0x7FFC
#define FUNCTION_prog_argv_stack 0x7FFE
#define FUNCTION_clip_mask 0xB003
#define FUNCTION_lcd_buffer 0xB100
#define FUNCTION_var_lcd_x 0xBB10
#define FUNCTION_var_lcd_y 0xBB11
#define FUNCTION_var_lcd_invert 0xBB12
#define FUNCTION_var_lcd_size 0xBB13
#define FUNCTION_var_sys_lib_index 0xBB14
#define FUNCTION_var_lcd_custom_scroll 0xBB16
#define FUNCTION_isr_clock_int 0xBB17
#define FUNCTION_var_buffered_draw 0xBB18
#define FUNCTION_var_UVP_state 0xBB19
#define FUNCTION_var_UVP_buffer_size 0xBB1A
#define FUNCTION_var_lcd_scroll_x1 0xBB1C
#define FUNCTION_var_lcd_scroll_x2 0xBB1D
#define FUNCTION_var_lcd_scroll_y1 0xBB1E
#define FUNCTION_var_lcd_scroll_y2 0xBB1F
#define FUNCTION_var_key_get 0xBB20
#define FUNCTION_var_sys_lib_stack 0xBB2E
#define FUNCTION_prog_registers 0xBB50
#define FUNCTION_var_key_mode 0xBB56
#define FUNCTION_var_UVP_buffer 0xBB57
#define FUNCTION_var_UVP_vp_size 0xBB59
#define FUNCTION_var_UVP_buffer_moving 0xBB5B
#define FUNCTION_var_UVP_mask 0xBB5D
#define FUNCTION_isr_real_mode 0xC000
#define FUNCTION_isr_powersave 0xC010
#define FUNCTION_isr_usb 0xC011
#define FUNCTION_isr_tasking 0xC012
#define FUNCTION_isr_launch 0xC014
#define FUNCTION_isr_is_off 0xC015
#define FUNCTION_isr_custom 0xC016
#define FUNCTION_isr_custom_page 0xC017
#define FUNCTION_isr_custom_location 0xC018
#define FUNCTION_var_sys_isEmulator 0xC01A
#define FUNCTION_bMaxPacketSize0 0xC020
#define FUNCTION_responseBytesRemaining 0xC022
#define FUNCTION_USBState 0xC024
#define FUNCTION_newAddressReceived 0xC026
#define FUNCTION_wAddress 0xC028
#define FUNCTION_bytesBuffered 0xC02A
#define FUNCTION_incomingDataReadyMap 0xC048
#define FUNCTION_rawSize 0xC049
#define FUNCTION_USB_ReceivedVirtualPacket 0xC04B
#define FUNCTION_USB_CurrentPacketOffset 0xC04D
#define FUNCTION_USB_CurrentPacketSize 0xC04F
#define FUNCTION_USB_CurrentPacketCommandID 0xC051
#define FUNCTION_peripheralInterface 0xC053
#define FUNCTION_controlDataAddress 0xC055
#define FUNCTION_var_sys_currentThread 0xC091
#define FUNCTION_var_registers 0xC092
#define FUNCTION_var_sys_isr_PC 0xC092
#define FUNCTION_var_sys_isr_af 0xC094
#define FUNCTION_var_sys_isr_bc 0xC096
#define FUNCTION_var_sys_isr_de 0xC098
#define FUNCTION_var_sys_isr_hl 0xC09A
#define FUNCTION_var_sys_isr_iy 0xC09C
#define FUNCTION_var_sys_isr_ix 0xC09E
#define FUNCTION_var_sys_isr_SP 0xC0A0
#define FUNCTION_var_processes 0xC100
#define FUNCTION_var_max_processes 0xC124
#define FUNCTION_isr_random 0xC125
#define FUNCTION_var_process_names 0xC127
#define FUNCTION_usb_stack 0xC1C1
#define FUNCTION_usb_pak_data 0xC200
#define FUNCTION_usb_pak_size 0xC220
#define FUNCTION_var_usb_connected 0xC221
#define FUNCTION_flashUnlock 0x4000
#define FUNCTION_flashUnlock_start 0x4000
#define FUNCTION_CHAR_EP 0x400B
#define FUNCTION_flashUnlock_end 0x400B
#define FUNCTION_CHAR_QUOTE 0x4013
#define FUNCTION_CHAR_POUND 0x401B
#define FUNCTION_CHAR_DOLLAR 0x4023
#define FUNCTION_CHAR_PERCENT 0x402B
#define FUNCTION_CHAR_AMP 0x4033
#define FUNCTION_CHAR_APP 0x403B
#define FUNCTION_CHAR_LPAREN 0x4043
#define FUNCTION_CHAR_RPAREN 0x404B
#define FUNCTION_CHAR_ASTERISK 0x4053
#define FUNCTION_CHAR_PLUS 0x405B
#define FUNCTION_CHAR_COMMA 0x4063
#define FUNCTION_CHAR_MINUS 0x406B
#define FUNCTION_CHAR_PERIOD 0x4073
#define FUNCTION_CHAR_FSLASH 0x407B
#define FUNCTION_CHAR_0 0x4083
#define FUNCTION_CHAR_1 0x408B
#define FUNCTION_CHAR_2 0x4093
#define FUNCTION_CHAR_3 0x409B
#define FUNCTION_CHAR_4 0x40A3
#define FUNCTION_CHAR_5 0x40AB
#define FUNCTION_CHAR_6 0x40B3
#define FUNCTION_CHAR_7 0x40BB
#define FUNCTION_CHAR_8 0x40C3
#define FUNCTION_CHAR_9 0x40CB
#define FUNCTION_CHAR_COLON 0x40D3
#define FUNCTION_CHAR_SEMICOLON 0x40DB
#define FUNCTION_CHAR_LTHAN 0x40E3
#define FUNCTION_CHAR_EQUALS 0x40EB
#define FUNCTION_CHAR_GTHAN 0x40F3
#define FUNCTION_CHAR_QM 0x40FB
#define FUNCTION_CHAR_AT 0x4103
#define FUNCTION_CHAR_A 0x410B
#define FUNCTION_CHAR_B 0x4113
#define FUNCTION_CHAR_C 0x411B
#define FUNCTION_CHAR_D 0x4123
#define FUNCTION_CHAR_E 0x412B
#define FUNCTION_CHAR_F 0x4133
#define FUNCTION_CHAR_G 0x413B
#define FUNCTION_CHAR_H 0x4143
#define FUNCTION_CHAR_I 0x414B
#define FUNCTION_CHAR_J 0x4153
#define FUNCTION_CHAR_K 0x415B
#define FUNCTION_CHAR_L 0x4163
#define FUNCTION_CHAR_M 0x416B
#define FUNCTION_CHAR_N 0x4173
#define FUNCTION_CHAR_O 0x417B
#define FUNCTION_CHAR_P 0x4183
#define FUNCTION_CHAR_Q 0x418B
#define FUNCTION_CHAR_R 0x4193
#define FUNCTION_CHAR_S 0x419B
#define FUNCTION_CHAR_T 0x41A3
#define FUNCTION_CHAR_U 0x41AB
#define FUNCTION_CHAR_V 0x41B3
#define FUNCTION_CHAR_W 0x41BB
#define FUNCTION_CHAR_X 0x41C3
#define FUNCTION_CHAR_Y 0x41CB
#define FUNCTION_CHAR_Z 0x41D3
#define FUNCTION_CHAR_LBLOCK 0x41DB
#define FUNCTION_CHAR_BSLASH 0x41E3
#define FUNCTION_CHAR_RBLOCK 0x41EB
#define FUNCTION_CHAR_CARRET 0x41F3
#define FUNCTION_CHAR_UNDERSCORE 0x41FB
#define FUNCTION_CHAR_ACCENT 0x4203
#define FUNCTION_CHAR_a 0x420B
#define FUNCTION_CHAR_b 0x4213
#define FUNCTION_CHAR_c 0x421B
#define FUNCTION_CHAR_d 0x4223
#define FUNCTION_CHAR_e 0x422B
#define FUNCTION_CHAR_f 0x4233
#define FUNCTION_CHAR_g 0x423B
#define FUNCTION_CHAR_h 0x4243
#define FUNCTION_CHAR_i 0x424B
#define FUNCTION_CHAR_j 0x4253
#define FUNCTION_CHAR_k 0x425B
#define FUNCTION_CHAR_l 0x4263
#define FUNCTION_CHAR_m 0x426B
#define FUNCTION_CHAR_n 0x4273
#define FUNCTION_CHAR_o 0x427B
#define FUNCTION_CHAR_p 0x4283
#define FUNCTION_CHAR_q 0x428B
#define FUNCTION_CHAR_r 0x4293
#define FUNCTION_CHAR_s 0x429B
#define FUNCTION_CHAR_t 0x42A3
#define FUNCTION_CHAR_u 0x42AB
#define FUNCTION_CHAR_v 0x42B3
#define FUNCTION_CHAR_w 0x42BB
#define FUNCTION_CHAR_x 0x42C3
#define FUNCTION_CHAR_y 0x42CB
#define FUNCTION_CHAR_z 0x42D3
#define FUNCTION_CHAR_LBRACK 0x42DB
#define FUNCTION_CHAR_PIPE 0x42E3
#define FUNCTION_CHAR_RBRACK 0x42EB
#define FUNCTION_CHAR_TILDE 0x42F3
#define FUNCTION_CHAR_DOT 0x42FB
#define FUNCTION_CHAR_IDK 0x4303
#define FUNCTION_CHAR_NULL 0x430B
#define FUNCTION_CHAR_SPACE 0x4313
#define FUNCTION_CHAR_SMALL_EP 0x431B
#define FUNCTION_CHAR_SMALL_QUOTE 0x4320
#define FUNCTION_CHAR_SMALL_POUND 0x4325
#define FUNCTION_CHAR_SMALL_DOLLAR 0x432A
#define FUNCTION_CHAR_SMALL_PERCENT 0x432F
#define FUNCTION_CHAR_SMALL_AMP 0x4334
#define FUNCTION_CHAR_SMALL_APP 0x4339
#define FUNCTION_CHAR_SMALL_LPAREN 0x433E
#define FUNCTION_CHAR_SMALL_RPAREN 0x4343
#define FUNCTION_CHAR_SMALL_ASTERISK 0x4348
#define FUNCTION_CHAR_SMALL_PLUS 0x434D
#define FUNCTION_CHAR_SMALL_COMMA 0x4352
#define FUNCTION_CHAR_SMALL_MINUS 0x4357
#define FUNCTION_CHAR_SMALL_PERIOD 0x435C
#define FUNCTION_CHAR_SMALL_FSLASH 0x4361
#define FUNCTION_CHAR_SMALL_0 0x4366
#define FUNCTION_CHAR_SMALL_1 0x436B
#define FUNCTION_CHAR_SMALL_2 0x4370
#define FUNCTION_CHAR_SMALL_3 0x4375
#define FUNCTION_CHAR_SMALL_4 0x437A
#define FUNCTION_CHAR_SMALL_5 0x437F
#define FUNCTION_CHAR_SMALL_6 0x4384
#define FUNCTION_CHAR_SMALL_7 0x4389
#define FUNCTION_CHAR_SMALL_8 0x438E
#define FUNCTION_CHAR_SMALL_9 0x4393
#define FUNCTION_CHAR_SMALL_COLON 0x4398
#define FUNCTION_CHAR_SMALL_SEMICOLON 0x439D
#define FUNCTION_CHAR_SMALL_LTHAN 0x43A2
#define FUNCTION_CHAR_SMALL_EQUALS 0x43A7
#define FUNCTION_CHAR_SMALL_GTHAN 0x43AC
#define FUNCTION_CHAR_SMALL_QM 0x43B1
#define FUNCTION_CHAR_SMALL_AT 0x43B6
#define FUNCTION_CHAR_SMALL_A 0x43BB
#define FUNCTION_CHAR_SMALL_B 0x43C0
#define FUNCTION_CHAR_SMALL_C 0x43C5
#define FUNCTION_CHAR_SMALL_D 0x43CA
#define FUNCTION_CHAR_SMALL_E 0x43CF
#define FUNCTION_CHAR_SMALL_F 0x43D4
#define FUNCTION_CHAR_SMALL_G 0x43D9
#define FUNCTION_CHAR_SMALL_H 0x43DE
#define FUNCTION_CHAR_SMALL_I 0x43E3
#define FUNCTION_CHAR_SMALL_J 0x43E8
#define FUNCTION_CHAR_SMALL_K 0x43ED
#define FUNCTION_CHAR_SMALL_L 0x43F2
#define FUNCTION_CHAR_SMALL_M 0x43F7
#define FUNCTION_CHAR_SMALL_N 0x43FC
#define FUNCTION_CHAR_SMALL_O 0x4401
#define FUNCTION_CHAR_SMALL_P 0x4406
#define FUNCTION_CHAR_SMALL_Q 0x440B
#define FUNCTION_CHAR_SMALL_R 0x4410
#define FUNCTION_CHAR_SMALL_S 0x4415
#define FUNCTION_CHAR_SMALL_T 0x441A
#define FUNCTION_CHAR_SMALL_U 0x441F
#define FUNCTION_CHAR_SMALL_V 0x4424
#define FUNCTION_CHAR_SMALL_W 0x4429
#define FUNCTION_CHAR_SMALL_X 0x442E
#define FUNCTION_CHAR_SMALL_Y 0x4433
#define FUNCTION_CHAR_SMALL_Z 0x4438
#define FUNCTION_CHAR_SMALL_LBLOCK 0x443D
#define FUNCTION_CHAR_SMALL_BSLASH 0x4442
#define FUNCTION_CHAR_SMALL_RBLOCK 0x4447
#define FUNCTION_CHAR_SMALL_CARRET 0x444C
#define FUNCTION_CHAR_SMALL_UNDERSCORE 0x4451
#define FUNCTION_CHAR_SMALL_ACCENT 0x4456
#define FUNCTION_CHAR_SMALL_LBRACK 0x445B
#define FUNCTION_CHAR_SMALL_PIPE 0x4460
#define FUNCTION_CHAR_SMALL_RBRACK 0x4465
#define FUNCTION_CHAR_SMALL_TILDE 0x446A
#define FUNCTION_CHAR_SMALL_IDK 0x446F
#define FUNCTION_CHAR_SMALL_RIGHT_ARROW 0x4474
#define FUNCTION_flashLock 0x4479
#define FUNCTION_flashLock_start 0x4479
#define FUNCTION_ASSERT 0x4484
#define FUNCTION_ASSERT_start 0x4484
#define FUNCTION_flashLock_end 0x4484
#define FUNCTION_ASSERT_end 0x44A1
#define FUNCTION_flashWrite 0x44A1
#define FUNCTION_flashWrite_start 0x44A1
#define FUNCTION_flashErase 0x44E1
#define FUNCTION_flashErase_start 0x44E1
#define FUNCTION_flashWrite_end 0x44E1
#define FUNCTION_flashErase_end 0x4533
#define FUNCTION_flashSetExecution 0x4533
#define FUNCTION_flashSetExecution_start 0x4533
#define FUNCTION_flashSetExecution_end 0x4549
#define FUNCTION_maketime 0x4549
#define FUNCTION_maketime_start 0x4549
#define FUNCTION_doClock 0x454E
#define FUNCTION_doClock_start 0x454E
#define FUNCTION_maketime_end 0x454E
#define FUNCTION_doClock_end 0x4EF2
#define FUNCTION_monthDays 0x4F0A
#define FUNCTION_strcpy 0x4FDA
#define FUNCTION_strcpy_start 0x4FDA
#define FUNCTION_strcpy_end 0x4FFF
#define FUNCTION_LCD_copy 0x5018
#define FUNCTION_LCD_copy_start 0x5018
#define FUNCTION_LCD_copy_end 0x501A
#define FUNCTION_LCD_drawFRect 0x501A
#define FUNCTION_LCD_drawFRect_start 0x501A
#define FUNCTION_LCD_drawFRect_end 0x501C
#define FUNCTION_Key_store 0x5064
#define FUNCTION_Key_store_start 0x5064
#define FUNCTION_Key_store_end 0x5066
#define FUNCTION_heap_malloc 0x5066
#define FUNCTION_heap_malloc_start 0x5066
#define FUNCTION_heap_malloc_end 0x5068
#define FUNCTION_Key_pressed 0x50AC
#define FUNCTION_Key_pressed_start 0x50AC
#define FUNCTION_Key_pressed_end 0x50AE
#define FUNCTION_LCD_drawRRect 0x50C5
#define FUNCTION_LCD_drawRRect_start 0x50C5
#define FUNCTION_LCD_drawRRect_end 0x50C7
#define FUNCTION_checkBatt 0x50C7
#define FUNCTION_checkBatt_start 0x50C7
#define FUNCTION_checkBatt_end 0x50C9
#define FUNCTION_puts 0x50C9
#define FUNCTION_puts_start 0x50C9
#define FUNCTION_puts_end 0x510E
#define FUNCTION_strcat 0x510E
#define FUNCTION_strcat_start 0x510E
#define FUNCTION_ion_copybuffer 0x5139
#define FUNCTION_ion_copybuffer_start 0x5139
#define FUNCTION_strcat_end 0x5139
#define FUNCTION_heap_free 0x513B
#define FUNCTION_heap_free_start 0x513B
#define FUNCTION_ion_copybuffer_end 0x513B
#define FUNCTION_heap_free_end 0x513D
#define FUNCTION_sys_execLibf 0x513D
#define FUNCTION_sys_execLibf_start 0x513D
#define FUNCTION_putchar 0x513F
#define FUNCTION_putchar_rr_s 0x513F
#define FUNCTION_sys_execLibf_end 0x513F
#define FUNCTION_putchar_rr_dbs 0x5148

// Created by autoheader.php | DO NOT MODIFY!!! REBUILD INSTEAD!!!
// Call these functions to use OS calls
#include "global.h"

#ifndef AUTOHEADER_MANUAL
void _flashUnlock (void) __naked
{
  __asm
    call #0x4000
    ret
  __endasm;
}
void _flashLock (void) __naked
{
  __asm
    call #0x4479
    ret
  __endasm;
}
void _flashWrite (unsigned char data, unsigned char *address, char page) __naked
{
  __asm
    call #0x44A1
    ret
  __endasm;
}
void _flashErase (byte page) __naked
{
  __asm
    call #0x44E1
    ret
  __endasm;
}
void _flashSetExecution (void) __naked
{
  __asm
    call #0x4533
    ret
  __endasm;
}
void _doClock (void) __naked
{
  __asm
    call #0x454E
    ret
  __endasm;
}

#else
#ifdef INCLUDE_flashUnlock
void flashUnlock (void) __naked
{
  __asm
    ld iy,#0x4000
    jp (iy)
  __endasm;
}
#endif
#ifdef INCLUDE_flashLock
void flashLock (void) __naked
{
  __asm
    ld iy,#0x4479
    jp (iy)
  __endasm;
}
#endif
#ifdef INCLUDE_flashWrite
void flashWrite (unsigned char data, unsigned char *address, char page) __naked
{
  __asm
    ld iy,#0x44a1
    jp (iy)
  __endasm;
}
#endif
#ifdef INCLUDE_flashErase
void flashErase (byte page) __naked
{
  __asm
    ld iy,#0x44e1
    jp (iy)
  __endasm;
}
#endif
#ifdef INCLUDE_flashSetExecution
void flashSetExecution (void) __naked
{
  __asm
    ld iy,#0x4533
    jp (iy)
  __endasm;
}
#endif
#ifdef INCLUDE_doClock
void doClock (void) __naked
{
  __asm
    ld iy,#0x454e
    jp (iy)
  __endasm;
}
#endif
#endif
// Created by autoheader.php | DO NOT MODIFY!!! REBUILD INSTEAD!!!
#endif
