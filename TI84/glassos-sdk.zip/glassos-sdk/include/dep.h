#include <stdbool.h>

/**
 * @defgroup debug Debugging routines
 * @brief These function help with debugging
 * @details These function can be included into your program to allow
 * you to test certain parts of your program oncalc.
 * @{
 */

/** Used to break current execution if a test fails.
 * 
 * If test is false, then the current program aborts displaying a message
 * @param test Used to test if the program should abort
 * @param message Displays text from here, RAM or ROM
 * @return Never returns
 */
void ASSERT(bool test, char *message)
{
  message;
  if(!test)
  {
    // We can be destructive!!!
    /*
     * Assert wants the stack like this:
     * rst return
     * message
     * return to actual program
     * 
     * The stack right now is:
     * return
     * bool (1)
     * message
     */
    __asm
    pop ix
    pop hl
    dec sp
    pop af
    pop de
    ld sp,#0xffff
    push de
    push hl
    
    rst #0x10
    ; Good bye!
    __endasm;
  }
}
/** 
 * @}
 */