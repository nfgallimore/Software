long _modslong (long a, long b) __naked
{
  a;b;
  __asm
    rst #0x18
    .db #2
    .dw #5
    ret
  __endasm;
}