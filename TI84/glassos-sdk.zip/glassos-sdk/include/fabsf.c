#define GLASSLIB_EXTERN
#include "glasslib.h"

float fabsf(const float x) __naked
{
  x;
  //return sys_execLibf(LIB_GLASSLIB, LIB_GLASSLIB_FABSF,x);
  __asm
  rst #0x18
  .db #1
  .dw #8
  ret
  __endasm;
}
