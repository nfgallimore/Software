#include "global.h"
#include "usb.h"

/**
 * @defgroup kernel Kernel functions
 * @brief Functions supported by the OS for critical operations
 * @details These are functions that can be called that handle OS-related functionality,
 * such as tasking, LCD access, and memory usage.
 * @{
 */ 

/// Simply creates a delay for the LCD in fast mode.
extern void LCD_stall();
extern void LCD_cWait(void);
extern void LCD_wWait(void);
/** Sets the LCD's X coord
 * 
 * Safely sends the X coord command to the LCD
 * @param x X coord
 */
extern void LCD_setX(byte x);
/** Sets the LCD's Y coord
 * 
 * Safely sends the Y coord command to the LCD
 * @param y Y coord
 */
extern void LCD_setY(byte y);
extern void LCD_wWrite(char data);
/** Sets up the auto Y inc.
 */
extern void LCD_setAutoInc(void);
/** Draws a masked sprite line.
 * 
 * Draws a row of masked sprite data
 * @param data Data to draw
 * @param range Range of data that should be masked on (1 is data, 0 is background)
 * @param y Y coord to draw on
 */
extern void LCD_drawSpriteLineM(unsigned char data, unsigned char range, char y);
/** Draws a masked sprite.
 * 
 * Draws a masked sprite directly to the LCD
 * 
 * @param data Array of sprite data
 * @param len Length of array, aka height of sprite
 * @param x X coord to place sprite at
 * @param y Y coord to place sprite at
 */
extern void LCD_drawSprite8M(char *data, char len, char x, char y);
/** Draws a masked sprite.
 * 
 * @warning Please use LCD_drawSprite8MChar instead!
 */
extern void LCD_drawSprite8MChar(char *data, char len, char x, char y, byte width);
/** Sets up the LCD.
 * 
 * Initializes and powers up the LCD.
 */
extern void LCD_setup(void);
/** Clears the LCD.
 * 
 * Slow way of clearing the LCD.
 */
extern void LCD_clear(void);
/** Draws a sprite by means of a character.
 * 
 * Draws a character to the LCD and updates the cursor location
 * @param data Pointer to character sprite data
 */
extern void LCD_drawChar(char *data);
/** Standard function, draws char to LCD
 * 
 * Draws a character to the LCD.  It also handles formatting (non-printing characters)
 * Types of special characters
 * - \0 - prints nothing
 * - \r - Clears the screen
 * - \b - backspace, but doesn't always work (see bug for LCD_drawSprite8M() )
 * - \002 - Turns on inverted text display
 * - \003 - Turns off inverted text display
 * - \004 - Sets font to small
 * - \005 - Sets font to large
 * 
 * @param x Character to print
 */
extern void putchar(char x);
/** Draws a horiz line
 * 
 * Draws a line going left-to-right
 * @warning Use LCD_drawLine instead as this just calls it
 * @param x1 X coord for the start of line
 * @param y1 X coord for the start of line
 * @param x2 Length of the line
 */
extern void LCD_drawHoriz(byte x1, byte y1, byte x2);
/** Draws a horiz. line with pattern
 * 
 * Draws an 8 pixel long pattern over a line
 * 
 * @param x1 X coord
 * @param y1 Y coord
 * @param x2 X coord of end point
 * @param color Pattern to draw line with
 */
extern void LCD_drawHorizC(byte x1, byte y1, byte x2, byte color);
/** Draws a vertical line
 * 
 * @warning Use LCD_drawLine instead as this just calls it
 * @param x X coord
 * @param y Y coord
 * @param len Length of line
 */
extern void LCD_drawVert(byte x, byte y, byte len);
extern void LCD_plotpixel(byte x, byte y);
/** Draws a line using different methods
 * 
 * This function does vertical lines, horizontal, and slopped lines
 * 
 * @param x1 X coord of start
 * @param y1 Y coord of start
 * @param x2 X coord of destination
 * @param y2 Y coord of destination
 */
extern void LCD_drawLine(byte x0, byte y0, byte x1, byte y1);
/// Adds in needed wait time between keyboard accesses
extern void Key_stall() __naked;
/// Low-level keyboard group setting, stall included beforehand
extern void Key_setGroup(byte group);
/** Directly reads keyboard for key press
 * 
 * Doesn't stall beforehand
 * @returns Boolean value for pressed/not pressed
 */
extern unsigned char Key_isDown(byte code);
/** Maps the memory for the OS
 * 
 * Sets the RAM/ROM pages with one call with error checking
 * @param b1 Page for 0x4000-0x7FFF
 * @param b2 Page for 0x8000-0xBFFF
 * @param b3 RAM page for 0xC000-0xFFFF
 */
extern void sys_map(BYTE b1, BYTE b2, BYTE b3);
/** Initializes a HEAP2 in the flash
 * 
 * @warning Addresses are local to 0x4000
 * 
 * @param start Start address for the heap, normally 0x4000
 * @param end End address
 * @param page ROM page that the heap should be written to
 */
extern void heap2_init(unsigned int start, unsigned int end, byte page);
/** Malloc's a piece of the flash and returns a pointer to the address
 * 
 * @param size Initial size of HEAP2 entry, 0xFFFF if not known
 * @param id ID of file system entry.  ID @b MUST match for a data node and index node, else deleted
 * @param parent ID of parent, 0x0000 if none
 * @param start Address of the start of the heap, normally 0x4000
 * @param page Page that the heap is on
 * @returns Pointer to the flash location - DO NOT FREE THIS!
 */
extern void* heap2_malloc(unsigned int size, unsigned int id, unsigned int parent, void *start, unsigned int page);
/// Returns free space in the HEAP2
extern U_INT heap2_getFree(byte page);
/// Returns size of deleted nodes in the HEAP2
extern U_INT heap2_getDeleted(byte page);
/** Walks through heap2 nodes on a page
 * 
 * Use like strtok.  Set node to 0, then call until returns non-zero.
 * @param node Pointer to node pointer - allocated and can be read
 * @param address pointer to address - Contains absolute address in ROM
 * @param page Page to read from, don't change when calling
 * @returns 0 if a node was read
 * @returns >0 if no more nodes are available
 */
extern unsigned char heap2_walk(heap2_n **node, unsigned int *address, unsigned char page);
/// Returns free space in the RAM
extern U_INT heap_getFree(char page);
/** Simple checking of a HEAP2
 * 
 * @returns 1 on pass
 * @returns 0 on fail
 */
extern byte heap2_check(char page);
/** Creates a heap in the RAM
 * 
 * @param start Start address of the heap, usually 0x8000
 * @param end End address of the heap
 */
extern void heap_init(void *start, void *end);
/** Creates a heap in the RAM with offset
 * 
 * Use this if you want to create a heap in a different memory bank
 * 
 * @param start Start address of the physical location of the heap, usually 0x4000
 * @param end End address of the heap
 * @param offset Offset from where the heap will be accessed from, usually 0x4000
 */
extern void heap_init_far(void *start, void *end, int offset);
/** Malloc's data in a heap
 * 
 * @param size Length of memory needed
 * @param start Starting location of the heap, usually 0x8000
 * @returns Pointer to the start of the memory, not the heap entry
 */
extern void* heap_malloc (unsigned int size, void *start);
/** Frees a malloc'd pointer
 * 
 * This will return if the pointer has been freed, no worries
 * 
 * @param p Pointer to malloc'd data - heap location not needed
 */
extern void heap_free (void *p);
/** Erases a sector
 * 
 * Given a page, the sector will be erased
 * @warning Do not use this directly
 * 
 * @param page Page in the sector to be erased
 */
extern void flashErase(byte page);
/** This will save all of the process's data and go to the launcher
 * 
 * @warning Do not call this, the ISR will call it specially
 */
extern void sys_haltProcess(unsigned int PC);
/** Executes a process
 * 
 * This will initialize a program to run and will add the process
 * entry in the process list.
 * 
 * Optimized - saved 32 bytes
 * 
 * @param proccessNumber Process number for binary, or 0 if Launcher
 * @param page ROM page that the binary is on
 * @param argc Size of the argv array
 * @param argv Array of paramters, or NULL if none
 * @param parent The uuid of the process to execute when this one finishes, or 0 to go to Launcher.
 */
extern void sys_setupProcess(char processNumber, unsigned char page, int argc, char** argv, byte parent);
/** Resolves the page for a binary program or library
 * 
 * @param s Path and filename of a binary file - RAM or ROM stored
 * @param type FLAG_PROGRAM or FLAG_LIBRARY
 * @returns Page that the binary is on
 */
extern byte sys_findBinLib(char *s, byte type);
/** A simple way to start programs
 * 
 * Creates a new process and passes parameters
 * 
 * @param executable Path and filename of binary - RAM or ROM stored
 * @param argc Argument count for argv
 * @param argv Array of malloc_shared strings
 * @returns Program return number
 */
extern int sys_exec(char* executable, int argc, char** argv);
/** This code will force the ISR to quit and run the process.
 * 
 * @warning <b>ONLY RUN FROM ISR!!! NOT FOR USER USAGE!</b>
 */
extern void sys_startProcess();
/** Stops a process
 * 
 * @warning Call this from the ISR @b ONLY
 */
extern void sys_suspendProcess(byte id);
/// Kills a process
extern void sys_kill(char processID);
/// See sys_execLibf
extern void sys_execLib(byte page, unsigned int jumpID, ...) __naked;
/**
 * This calls a library function
 * 
 * @warning This function destroys iy.
 * @note This function is pure asm
 * 
 * This function swaps pages and executes a function, passing along the needed
 * parameters.  This function should be carefully called when in a library, as
 * a max of 3 calls deep is set.
 * 
 * This is to be used for static libraries that have a set page number.  User
 * libraries should use sys_libExec() (not started) instead.
 * 
 * The function works as follows:  The OS gets control of execution.  It stores
 * the PC, page, and passed parameters, sets the page for the library, and jumps
 * to the library's crt0 to use the jump table.  Execution returns to this
 * function, restores the stack, page, and PC.
 * 
 * @param page The page that the library is on
 * @param jumpID This is the index of the the jump in the Jump_Table (starting from
 * 0 and increasing by 1)
 * @param "..." Any parameters to pass to the function
 * @returns This returns a 4 byte nuber, so all data types can be returned
 */
extern float sys_execLibf(unsigned char page, unsigned int jumpID, ...) __naked;
/** Draws a rectangle
 * 
 * Draws a rectange to the LCD
 * 
 * @param x X coord of top left point
 * @param y Y coord of top left point
 * @param x2 X coord of bottom right point
 * @param y2 Y coord of bottom right point
 */
extern void LCD_drawRect(byte x, byte y, byte x2, byte y2);
/** Draws a rounded rectangle
 * 
 * Draws a rectange to the LCD, but with 1 pixel rounding
 * 
 * @param x X coord of top left point
 * @param y Y coord of top left point
 * @param x2 X coord of bottom right point
 * @param y2 Y coord of bottom right point
 */
extern void LCD_drawRRect(byte x, byte y, byte x2, byte y2);
/** Draws a filled rectangle with a pattern
 * 
 * @param x X coord of top left point
 * @param y Y coord of top left point
 * @param x2 X coord of bottom right point
 * @param y2 Y coord of bottom right point
 * @param color Pattern to draw, 0xFF to fill with black
 */
extern void LCD_drawFRect(byte x, byte y, byte x2, byte y2, byte color);
/// Resets the keyboard, not the buffer
extern void Key_clear();
/** Parses the keyboard and the key buffer
 * 
 * Call this function before Key_pressed().  This function will
 * read the key port, add the data to the key buffer, and determine what keys were pressed.
 * 
 * @returns 0 if no keys were pressed
 * @returns 1 if any numbers of keys are down (not necessarily pressed in the buffer)
 */
extern byte Key_store();
/** Checks to see if a certain key was pressed
 * 
 * This reads the buffer to check for a key down event
 * 
 * @param key Key number the check
 * @returns bool of the state
 */
extern byte Key_pressed(byte key);
/** Checks to see if a certain key is held down
 * 
 * This reads the buffer to check for a key down currently, not just the initial event
 * 
 * @param key Key number the check
 * @returns bool of the state
 */
extern byte Key_pressedDown(byte key);
/// Gets a character without blocking
extern char getc_nowait(void);
/// Gets a character, with blocking
extern char getc(void);
/// Redirect to getc
extern char getchar();
/** Direct copy of the LCD RAM
 * 
 * Reads the LCD buffer and dumps it to buffer
 * @param buffer buffer of size 12*64
 */
extern void LCD_copy(char *buffer);
/** Checks if all extra RAM is on the calc
 * 
 * @warning Uses port 0x15, but has code to check manually. Port 0x15 is nondestructive of the RAM
 * @returns true if 8 pages
 * @returns false if 3 pages
 */
extern byte IsAllExtraRAMPresent(void);
/** Initializes the ISR for running
 */
extern void setup_ISR(void);
/** A fancy all-in-one function for resetting the USB
 * 
 * @bug Will not re-enable after calling this
 */
extern void kill_USB();
/** Initializes USB.
 * 
 * This malloc's the peripheral, so kill it first @b before running this again
 */
extern void setup_USB(void);
/** Safely reads a byte from the flash
 * 
 * This will read a byte from the flash without disturbing executation.
 * @param page flash page that the data is on.
 * @param address address starting at 0x4000
 * @returns A byte from that address
 */
extern byte readFlashB(char page, unsigned int address);
/** Safely reads an array of bytes from the flash
 * 
 * This will read bytes from the flash without disturbing executation.
 * @param page flash page that the data is on.
 * @param address address starting at 0x4000
 * @param buffer Pointer to buffer
 * @param length Ammount of data to read
 */
extern void readFlashA(char page, unsigned int address, byte *buffer, unsigned int length);
/** Safely writes a byte from the flash
 * 
 * This will read a byte from the flash without disturbing executation.
 * @param page flash page that the data is on.
 * @param address address starting at 0x4000
 * @param data A byte to write
 */
extern void writeFlashB(char page, unsigned int address, byte data);
/** Safely writes an array of bytes from the flash
 * 
 * This will write bytes from the flash without disturbing executation.
 * @param page flash page that the data is on.
 * @param address address starting at 0x4000
 * @param buffer Pointer to buffer
 * @param length Ammount of data to write
 */
extern void writeFlashA(char page, unsigned int address, byte* data, unsigned int length);
extern void put_char_to_string (char c, void* p);
/** Copies character data to RAM
 * 
 * Copies a character from the system font to a buffer
 * @param c Character to get
 * @param buffer Buffer to copy to - at least 8 bytes
 * @returns 1 if read
 * @returns 0 if failed to get character
 */
extern char readFont(char c, char *buffer);
/** Sends a virtual packet
 * 
 * The following variables must be set before calling
 * - var_UVP_buffer
 * - var_UVP_vp_size
 * - var_UVP_mask
 */
extern void UVP_send();
/** Sets up the UVP callback
 * 
 * Makes your process use UVP.  This does not choose which services
 * need the VP, all packets are treated as VPs.
 * @param mask Service mask that uses VPs
 * @param size Max size of the buffer to create
 * @param cb The callback to call once a packet is processed
 */
extern void UVP_setup(unsigned long mask, unsigned int size, void *cb);
/** Gets battery state
 * 
 * @bug This functions works, but only returns 4 or 1
 * 
 * @returns 4-1, 4 being high, 1 for low
 */
extern unsigned char checkBatt();
/** Gets the greyscale freq. from user preferences
 * 
 * Reads the user preferences in /etc/greyfreq and returns the greyscale
 * frequency.  If no pref. file exists, returns a default 181
 * @returns User-chosen frequency, or 181 if none.
 */
extern unsigned char prefs_getgreyfreq();
/** Set the greyscale freq. in user preferences
 * 
 * Sets the user preferences in /etc/greyfreq.
 */
extern void prefs_setgreyfreq(byte freq);
/** Sets the contrast level in user preferences
 * 
 * Sets the user preferences in /etc/contrast for the LCD contrast.
 * 
 * @warning This only changes the stored value.  Call LCD_setup(); to
 * apply the change
 * 
 * @param level Contrast level on the rage [0,0x3F] [low,high]
 */
extern void prefs_setcontrast(byte level);
/** Gets the contrast level from user preferences
 * 
 * Reads the user preferences in /etc/contrast and returns the contrast
 * level.  If no pref. file exists, returns a default 0x30
 * @returns User-chosen contrast, 0x30 if none.
 */
extern byte prefs_getcontrast();
/** Erases pixels in a line
 * 
 * This is a buffered drawing function.  Erases a line from (x0,y0)
 * to (x1,y1).
 */
extern void gfx_lineClear(byte x0, byte y0, byte x1, byte y1);
/** Erases pixels in a line
 * 
 * This is a buffered drawing function.  Draws a line from (x0,y0)
 * to (x1,y1).
 */
extern void gfx_lineDraw(byte x0, byte y0, byte x1, byte y1);
/** Writes an array of data to the flash
 * 
 * See flashWrite
 * @warning Unstable
 * 
 * @param data Array of bytes
 * @param address location to write
 * @param length length of array
 * @param page page to write to
 * @returns status, 0 on success, >0 on fail
 */
extern void flashWriteBulk(BYTE* data, unsigned int address, unsigned int length, char page);
/**
 * @}
 */