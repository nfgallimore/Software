#define GLASSLIB_EXTERN
#include "glasslib.h"

int printf(char* c, ...) __naked
{
  c;
  __asm
  rst #0x18
  .db #1
  .dw #0
  ret
  __endasm;
}
