/*
    keyboard.h :: Defines for key codes in GlassOS
    Copyright (C) 2011 Collin Eggert

    GlassOS is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    GlassOS is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/
// What are these?
// The KC is the Key Code (Key Bit)
// The KR is the Key Row (Group Mask)
// Why the KC in bits?  So you can check for multiple keys!
// OR (|) them together when checking (Only the same KR, sorry)
// ... then what is KR_NULL?  To reset the groups!

  
#define KR_NULL		0xFF

#define KC_DOWN 	0x01
#define KC_LEFT 	0x02
#define KC_RIGHT 	0x04
#define KC_UP 		0x08
#define K_DOWN		0
#define K_LEFT		1
#define K_RIGHT		2
#define K_UP		3

#define KC_ENTER	0x01
#define KC_PLUS		0x02
#define KC_MINUS	0x04
#define KC_MULTIPLY	0x08
#define KC_DIVIDE	0x10
#define KC_POWER	0x20
#define KC_CLEAR	0x40
#define K_ENTER		8
#define K_PLUS		9
#define K_MINUS		10
#define K_MULTIPLY	11	
#define K_DIVIDE	12	
#define K_POWER		13
#define K_CLEAR		14

#define KC_NEG		0x01
#define KC_3		0x02
#define KC_6		0x04
#define KC_9		0x08
#define KC_RPAREN	0x10
#define KC_TAN		0x20
#define KC_VARS		0x40
#define K_NEG		16
#define K_3		17
#define K_6		18
#define K_9		19
#define K_RPAREN	20	
#define K_TAN		21
#define K_VARS		22

#define KC_PERIOD	0x01
#define KC_2		0x02
#define KC_5		0x04
#define KC_8		0x08
#define KC_LPAREN	0x10
#define KC_COS		0x20
#define KC_PRGM		0x40
#define KC_STAT		0x80
#define K_PERIOD	24	
#define K_2		25
#define K_5		26
#define K_8		27
#define K_LPAREN	28	
#define K_COS		29
#define K_PRGM		30
#define K_STAT		31

#define KC_0		0x01
#define KC_1		0x02
#define KC_4		0x04
#define KC_7		0x08
#define KC_COMMA	0x10
#define KC_SIN		0x20
#define KC_APPS		0x40
#define KC_XTON		0x80
#define K_0		32
#define K_1		33
#define K_4		34
#define K_7		35
#define K_COMMA		36
#define K_SIN		37
#define K_APPS		38
#define K_XTON		39

#define KC_STO		0x02
#define KC_LN		0x04
#define KC_LOG		0x08
#define KC_SQUARE	0x10
#define KC_INVERSE	0x20
#define KC_MATH		0x40
#define KC_ALPHA	0x80
#define K_STO		41
#define K_LN		42
#define K_LOG		43
#define K_SQUARE	44	
#define K_INVERSE	45	
#define K_MATH		46
#define K_ALPHA		47

#define KC_GRAPH	0x01
#define KC_TRACE	0x02
#define KC_ZOOM		0x04
#define KC_WINDOW	0x08
#define KC_YEQU		0x10
#define KC_2ND		0x20
#define KC_MODE		0x40
#define KC_DEL		0x80
#define K_GRAPH		48
#define K_F5		K_GRAPH
#define K_TRACE		49
#define K_F4		K_TRACE
#define K_ZOOM		50
#define K_F3		K_ZOOM
#define K_WINDOW	51
#define K_F2		K_WINDOW
#define K_YEQU		52
#define K_F1		K_YEQU
#define K_2ND		53
#define K_MODE		54
#define K_DEL		55

#define KR_DOWN 	0xFE
#define KR_LEFT 	0xFE
#define KR_RIGHT 	0xFE
#define KR_UP 		0xFE

#define KR_ENTER	0xFD
#define KR_PLUS		0xFD
#define KR_MINUS	0xFD
#define KR_MULTIPLY	0xFD
#define KR_DIVIDE	0xFD
#define KR_POWER	0xFD
#define KR_CLEAR	0xFD

#define KR_NEG		0xFB
#define KR_3		0xFB
#define KR_6		0xFB
#define KR_9		0xFB
#define KR_RPAREN	0xFB
#define KR_TAN		0xFB
#define KR_VARS		0xFB

#define KR_PERIOD	0xF7
#define KR_2		0xF7
#define KR_5		0xF7
#define KR_8		0xF7
#define KR_LPAREN	0xF7
#define KR_COS		0xF7
#define KR_PRGM		0xF7
#define KR_STAT		0xF7

#define KR_0		0xEF
#define KR_1		0xEF
#define KR_4		0xEF
#define KR_7		0xEF
#define KR_COMMA	0xEF
#define KR_SIN		0xEF
#define KR_APPS		0xEF
#define KR_XTON		0xEF

#define KR_STO		0xDF
#define KR_LN		0xDF
#define KR_LOG		0xDF
#define KR_SQUARE	0xDF
#define KR_INVERSE	0xDF
#define KR_MATH		0xDF
#define KR_ALPHA	0xDF

#define KR_GRAPH	0xBF
#define KR_TRACE	0xBF
#define KR_ZOOM		0xBF
#define KR_WINDOW	0xBF
#define KR_YEQU		0xBF
#define KR_2ND		0xBF
#define KR_MODE		0xBF
#define KR_DEL		0xBF

