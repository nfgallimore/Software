/*
    glasslib3.h :: Defines for glasslib3 in GlassOS
    Copyright (C) 2011 Collin Eggert

    GlassOS is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    GlassOS is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#include "global.h"
#define LIB_GLASSLIB3 0x04
#define LIB_GLASSLIB3_FS_FORMAT 0
#define LIB_GLASSLIB3_REMOVE 0x01
#define LIB_GLASSLIB3_FOPEN 0x02
#define LIB_GLASSLIB3_FS_CHECKSANITY 0x03
#define LIB_GLASSLIB3_FCLOSE 0x04
#define LIB_GLASSLIB3_FPUTC 0x05
#define LIB_GLASSLIB3_FPUTS 0x06
#define LIB_GLASSLIB3_FGETC 0x07
#define LIB_GLASSLIB3_MKDIR 0x08
#define LIB_GLASSLIB3_OPENDIR 0x09
#define LIB_GLASSLIB3_CLOSEDIR 0x0A
#define LIB_GLASSLIB3_RESETDIR 0x0B
#define LIB_GLASSLIB3_READDIR 0x0C
#define LIB_GLASSLIB3_HEAP2_DEFRAG 0x0D
#define LIB_GLASSLIB3_FS_DEFRAGSECTOR 0x0E
#ifndef SDCC
#define __naked
#endif

/**
 * @defgroup glasslib3 File IO commands from glasslib3
 * @brief This system library contains functions from stdio.h relating to files
 * @details This system library, stored on ROM page @b 0x04, contains all fs_* and stdio commands.
 * This library will take up a lot of space as it uses robust functions.  Not all functions are available
 * for library calls.  Only functions that are noted as such can be called.
 * @{
 */
/** Closes a DIR
 * frees a DIR* struct and child dirent's
 * @param dirp The DIR struct to be closed
 */
extern void closedir(DIR* dirp) __naked;
/** Closes a file struct
 * frees a FILE struct and finalizes writes/reads
 * @param f FILE to be closed
 */
extern void fclose(FILE* f) __naked;
/** Read one byte
 * Reads a byte or char from a FILE struct
 * @param f FILE struct that is opened in 'r' mode
 * @returns 1 byte from file
 */
extern byte fgetc(FILE* f) __naked;
/** Opens a FILE struct
 * Creates a FILE struct for reading/writing
 * @param s Full path with filename for creating a file.  No error checking!
 * @param mode Type of FILE to create.
 *  * 'r' - read, null if not found
 *  * 'w' - write, creates new file.
 *  * 'a' - append, appends to existing file
 * @returns Malloc'd FILE struct, null on error
 */
extern FILE* fopen(char* s, char mode) __naked;
/** Writes a block of arrays to a file
 * 
 * Writes @b count items of size @b size from array @b data to file @b f.
 * 
 * @note Use this instead of fputs when using binary data.
 * 
 * @param data Pointer to array
 * @param size size of each element
 * @param count number of elements
 * @param f File to write to
 */
extern void fwrite(void* data, size_t size, size_t count, FILE* f);
/** Reads a block of arrays to a file
 * 
 * Reads @b count items of size @b size from array @b data to file @b f.
 * 
 * @param data Pointer to array
 * @param size size of each element
 * @param count number of elements
 * @param f File to read from
 */
extern void fread(void* data, size_t size, size_t count, FILE* f);
/** Writes a byte
 * Writes a byte to a file
 * @param character Byte to write at current position
 * @param f FILE struct that is opened for writing
 */
extern void fputc(byte character, FILE* f) __naked;
/** Writes a null-terminated string
 * @param data Malloc'd pointer, required
 * @param f FILE struct
 */
extern void fputs(char* data, FILE* f) __naked;
/** Checks the entire fs for errors in a poor way.
 * 
 * @returns 0 on fail
 * @returns 1 on pass
 */
extern byte fs_checkSanity() __naked;
/** Defragments a sector
 * Removes deleted nodes from a sector and writes them to the swap
 * and becomes the new swap.
 * @param source Page in a sector
 * @returns 1 on success
 * @returns 0 on failure
 */
extern byte fs_defragSector(byte source) __naked;
/** Formats the flash chip
 * @warning Destroys all data
 */
extern void fs_format() __naked;
/** Defragments a heap2
 * Manually controlls a defrag.  For normal use, see fs_defragSector()
 * @param sourcepage Fragmented page
 * @param destpage Output page, doesn't need to be empty, but must be formatted
 * @returns 1 on success
 * @returns 0 on failure
 */
extern byte heap2_defrag(byte sourcepage, byte destpage) __naked;
/** Creates a directory
 * Creates a folder using a full path without a trailing '/'
 * @param s Path and folder name
 * @warning No error checking on @b s
 * @returns true on success
 * @returns false on failure
 */
extern unsigned char mkdir(char *s) __naked;
/** Opens a directory for reading
 * Creates a malloc'd DIR structure for reading the contents of a directory. See the standard libc documentation for exact usage.
 * @param dirname Full path of directory without trailing '/'
 * @returns Malloc'd DIR
 * @returns NULL if the directory is invalid
 */
extern DIR* opendir(char *dirname) __naked;
/** Reads a DIR struct
 * Reads a folder and gets information about the read node
 * @param dirp DIR struct
 * @returns struct describing read node
 * @returns NULL if the end was reached
 * @warning Do not free the dirent!
 */
extern dirent* readdir(DIR* dirp) __naked;
/** Deletes a file
 * This will remove a file from the FS index
 * @bug Does this work reliably on folders?
 * @param s Full path
 * @returns true on error
 * @returns false on success
 */
extern byte remove(char* s) __naked;
/** Resets a DIR struct
 * Sets a DIR struct to re-read a folder
 * @param dirp Malloc'd DIR
 */
extern void resetdir(DIR* dirp);
/** Updates a binary file
 * Searches through the FS for a binary file pointing to @param oldpage
 * and replaces it with one pointing to @param newpage
 * @param oldpage Current page
 * @param newpage New page
 * @returns 0 on success
 * @returns 1 when no free space is available
 * @returns 2 when program not found
 */
extern byte fs_updateBinary(byte oldpage, byte newpage);
/** Removes a directory
 * 
 * Removes a folder from the filesystem.
 * @warning The folder must be empty
 * @param s Path to folder.  Do not end with '/', use something like /home/test
 * @returns true on success
 * @returns false on failure
 */
extern unsigned char rmdir(char *s);
/**
 * @}
 */