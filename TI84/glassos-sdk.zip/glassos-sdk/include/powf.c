float powf(const float x, const float y) __naked
{
  x;y;
  __asm
    rst #0x18
    .db #2
    .dw #4
    ret
  __endasm;
}