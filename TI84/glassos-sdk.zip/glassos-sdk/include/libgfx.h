#include "global.h"

#include "libgfx_defines.h"
#ifndef SDCC
#define __naked
#endif
#ifndef LCD_WIDTH
#define LCD_WIDTH 96
#endif
#ifndef LCD_HEIGHT
#define LCD_HEIGHT 64
#endif
/**
 * @defgroup libgfx Buffered LCD drawing library
 * @brief This library allows buffered LCD drawing.
 * @details This library is statically linked to your program and provides
 * buffered LCD drawing functions.  The buffer pointer, lcd_buffer, must be 
 * pointing to a malloc'd buffer of size 768 bytes.
 * @{
 */

/** Draws a sprite to the LCD buffer
 * Draw a sprite using an XOR method
 * @param sprite A byte array, 8 bit wide sprite
 * @param x X coord from the top left of the LCD
 * @param y Y coord from the top left of the LCD
 * @param height Height of the array
 */
extern void ion_putsprite(unsigned char *sprite, unsigned char x, unsigned char y, unsigned char height);
/** OR's a sprite to the LCD buffer
 * Draw a sprite using an OR method
 * @param sprite A byte array, 8 bit wide sprite
 * @param x X coord from the top left of the LCD
 * @param y Y coord from the top left of the LCD
 * @param height Height of the array
 */
extern void ion_putsprite_or(unsigned char *sprite, unsigned char x, unsigned char y, unsigned char height);
/** AND's a sprite to the LCD buffer
 * Draw a sprite using an AND method
 * @param sprite A byte array, 8 bit wide sprite
 * @param x X coord from the top left of the LCD
 * @param y Y coord from the top left of the LCD
 * @param height Height of the array
 */
extern void ion_putsprite_and(unsigned char *sprite, unsigned char x, unsigned char y,unsigned char height);
/** Draws a clipped sprite to the LCD buffer
 * Draw a sprite using an XOR method and does screen clipping
 * @warning Does this work? It may be buggy or non-functional
 * @param sprite A byte array, 8 bit wide sprite
 * @param x X coord from the top left of the LCD
 * @param y Y coord from the top left of the LCD
 * @param height Height of the array
 */
extern void gfx_putsprite_clipped(unsigned char *sprite, signed char x, signed char y, unsigned char height);
/** Draws the LCd buffer to the LCD
 * Copies the LCD buffer in lcd_buffer to the hardware
 */
extern void ion_copybuffer() __naked;
/** Clears the LCD buffer
 */
extern void gfx_clearbuffer();
/** Draws a tilemap to the buffer
 * Renders a tilemap from the provided structure
 */
extern void gfx_tilemap_draw(gfx_tilemap_data *td);
/** Draws a masked sprite
 */
extern void gfx_maskedsprite_draw(gfx_maskedsprite_data *data);
/** Draws an animated sprite and ticks
 * This will render an animated sprite, and then update the keyframe.  
 * It will repeat if needed.
 */
extern void gfx_animatedsprite_draw_and_tick(gfx_animatedsprite_data *s);
/** Inc's the keyframe of the animated sprite
 * This will not draw, just inc the keyframe, wrapping if needed.
 */
extern void gfx_animatedsprite_tick(gfx_animatedsprite_data *s);
/** This will render the current keyframe of the animated sprite
 */
extern void gfx_animatedsprite_draw(gfx_animatedsprite_data *s);
/** This renders the current keyframe using an XOR method
 */
extern void gfx_animatedsprite_draw_xor(gfx_animatedsprite_data *s);
/*
 * The following code is by Drew DeVault
 */
// FIXME:  These don't work!
/*
// gets a single pixel's value from the screen
unsigned char gfx_getPixel(unsigned char x, unsigned char y)
{
__asm
        ld a, 4(ix)
        ld l, 5(ix)
 
        ld      h, #0
        ld      d, h
        ld      e, l
 
        add     hl, hl
        add     hl, de
        add     hl, hl
        add     hl, hl
 
        ld      e, a
        srl     e
        srl     e
        srl     e
        add     hl, de
 
        ld a, (#(_lcd_buffer)) ; \ 0xB000 \ 0B000h depending on your assembler
        ld e, a
        ld a, (#(_lcd_buffer)+#1)
        ld d, a
 
        add     hl, de
 
        and     #7
        ld      b, a
        ld      a, #80
        jr      z, maskDone1
 pixelloop1:
        rrca
        djnz    pixelloop1
 
maskDone1:
        ld b, a
        ld a, (hl)
        ld c, b
        ld b, a
        ld a, c
 
        ; THIS CODE MIGHT NOT WORK.  Change it to OR if needed.
        and b ; isolate the individual pixel
 
        or a ; cp 0
        ld l, a
        pop ix
        ret z ; return if it is zero
        ld l, #1
        ret
__endasm;
}
  */
/** This will retrieve a pixel
 * A pixel will be returned as either 0b1 or 0b0.
 */
extern unsigned char getPixel(unsigned char x, unsigned char y);
/** Sets a pixel in the LCD buffer
 * @param value Changes the pixel depending on bit 0 @b only
 * @warning The above is what should happen, bugs may exist
 */
extern void setPixel(unsigned char x, unsigned char y, unsigned char value);

/** Draws a sprite by means of a character.
 * 
 * Draws a character to the LCD and updates the cursor location
 * @param data Pointer to character sprite data
 * @param x The actual character being drawn
 */
extern void gfx_drawChar(unsigned char *data, char x);
/*{
    //LCD_drawSprite8(data,8,var_lcd_x,var_lcd_y);
    // Oh snap, we MUST MASK due to non-uniform X values
    ion_putsprite(data,var_lcd_x, var_lcd_y,
			 (var_lcd_size ? 8 : 5));
    if (var_lcd_size == 1)
    {
        if (var_lcd_x >= 90)
        {
            var_lcd_x = 0;
            var_lcd_y += 8;
        }
        else
        {
            var_lcd_x += 6;
        }
    }
    else
    {
        // Variable width text here
        if (var_lcd_x >= 90)
        {
            var_lcd_x = 0;
            var_lcd_y +=5;
        }
        else
        {
                switch(tolower(x))
		{
		  case 'w':
		  case 'm':
		  case '~':
		  case 'n':
		    var_lcd_x += 6;
		    break;
		  default:
		    var_lcd_x += 4;
		}
        }
    }

    // Scroll!!!
    if (var_lcd_y > 56 && var_lcd_size == 1 || var_lcd_y > 59 && var_lcd_size == 0)
    {
        var_lcd_y = 0;
    }
}*/
/** GFX function, draws char to LCD buffer
 * 
 * Draws a character to the buffer.  It also handles formatting (non-printing characters)
 * Types of special characters
 * - \0 - prints nothing
 * - \r - Clears the screen
 * - \b - backspace, but doesn't always work (see bug for LCD_drawSprite8M() )
 * - \002 - Turns on inverted text display
 * - \003 - Turns off inverted text display
 * - \004 - Sets font to small
 * - \005 - Sets font to large
 * 
 * @param x Character to print
 */
extern void gfx_putchar(char x);
/*{
  // Use the OS call this time ;-)
  char *buffer = malloc(8);
  
  if(readFont(x,buffer))
  {
    // changed
    if(var_lcd_invert > 0)
    {
      byte i;
      char c = tolower(x);
      for(i = 0;i < 8; i++)
      {
	if(var_lcd_size == 1 || var_lcd_size == 0 && (c == 'n' || c == 'w' || c == 'm' || c == '~'))
	  buffer[i] ^= 0b11111100;
	else
	  buffer[i] ^= 0b11110000;
      }
    }
    gfx_drawChar(buffer, x);
  }
    free(buffer);
  
//     unsigned int oldpage = Port_Mem_B2;
//     unsigned char *pixmap = malloc_shared(8);
//     Port_Mem_B2 = 0x7C; // Characters
//     if (x == '\n')
//     {
//         var_lcd_x =  0;
//         if (var_lcd_size == 1)
//             var_lcd_y += 8;
//         else
//             var_lcd_y += 6;
//     }
//     else if (x == '\0')
//     {
// 
//     }
//     else if (x == ' ')
//     {
//         memmove(pixmap,0x8000+0x0313,8); // CHAR_SPACE
//     }
//     else if (x == '\004')
//     {
//         var_lcd_size = 0;
//     }
//     else if (x == '\005')
//     {
//         var_lcd_size = 1;
//     }
//     else
//     {
//         if (var_lcd_size == 0)
//         {
//             if ((x-33)<94)
//             {
//                 if (x >= (char)'[' && !islower(x))
//                 {
//                     memmove(pixmap, ((x-'[')*5+0x843D),8);
//                 }
//                 else
//                 {
//                     memmove(pixmap,((toupper(x)-33)*5+0x831B),8);
//                 }
//             }
//             // 200 = right arrow
//             else if (x == '\20')
//             {
//                 memmove(pixmap,0x8474,8);
//             }
//         }
//         else
//         {
//             if (x < 33)
//             {
//                 memmove(pixmap,0x8303,8);
//             }
//             else if ((x-33)<94)
//             {
//                 // Optimize this garbage (1.5K of garbage)
//                 memmove(pixmap,(CHAR_FAR_BIG+0x8000+0x08*(x-33)),8);
// 
//             }
//             else
//             {
//                 memmove(pixmap,(0x8000+0x0303),8);
//             }
//         }
//     }
//     Port_Mem_B2 = oldpage;
//     //gfx_drawChar(pixmap);
//     free(pixmap);
}*/
/** Draws a string of characters to the LCD buffer
 * See gfx_putchar() for formatting characters
 * Acts like puts(), but @b DOES @b NOT add an endline.  This must be done manually!
 */
extern void gfx_puts(char *s);
/*{
  while(*s)
    gfx_putchar(*(s++) );
}*/
/*
// sets a pixel to value
void gfx_setPixel(unsigned char x, unsigned char y, unsigned char value)
{
__asm
        ld a,4(ix)
        ld l,5(ix)
        ld c,6(ix)
 
        ld      h, #0
        ld      d, h
        ld      e, l
 
        add     hl, hl
        add     hl, de
        add     hl, hl
        add     hl, hl
 
        ld      e, a
        srl     e
        srl     e
        srl     e
        add     hl, de
 
        ld a, (#(_lcd_buffer))
        ld e, a
        ld a, (#(_lcd_buffer)+#1)
        ld d, a
 
        add     hl, de
 
        and     #7
        ld      b, a
        ld      a, #80
        jr      z, maskDone2
 pixelloop2:
        rrca
        djnz    pixelloop2
 
maskDone2:
        ;push af
        ld a, b
        cpl
        and (hl)
        ld (hl), a
        pop ix
        jr z, doReset2
 
        ret
doReset2:
        or (hl)
        ld (hl), a
        ret
__endasm;
}
*/
/**
 * @}
 */
