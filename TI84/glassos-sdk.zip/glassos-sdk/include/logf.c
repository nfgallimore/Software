float logf(const float x) __naked
{
  x;
  __asm
    rst #0x18
    .db #2
    .dw #11
    ret
  __endasm;
}