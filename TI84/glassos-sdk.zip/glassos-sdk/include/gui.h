/*
    gui.h :: Defines for gui in GlassOS
    Copyright (C) 2011 Collin Eggert

    GlassOS is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    GlassOS is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/
#ifndef sys_execLibf

#endif
#include "global.h"
#define LIB_GUI 3

#define LIB_GUI_GUI_Popup_Create 	0
#define LIB_GUI_GUI_Popup_Add		1
#define LIB_GUI_GUI_Popup_Do		2
#define LIB_GUI_GUI_Menubar_Create	3
#define LIB_GUI_GUI_Menubar_Add		4
#define LIB_GUI_GUI_Radio_Create	5
#define LIB_GUI_GUI_Radio_Draw		6
#define LIB_GUI_GUI_Radio_Erase		7
#define LIB_GUI_GUI_Checkbox_Create	8
#define LIB_GUI_GUI_Checkbox_Draw	9
#define LIB_GUI_GUI_Checkbox_Erase	10
#define LIB_GUI_GUI_Label_Create	11
#define LIB_GUI_GUI_Label_Draw		12
#define LIB_GUI_GUI_Label_Erase		13
#define LIB_GUI_GUI_Button_Create	14
#define LIB_GUI_GUI_Button_Draw		15
#define LIB_GUI_GUI_Button_Erase	16
#define LIB_GUI_GUI_Desktop_Create	17
#define LIB_GUI_GUI_Desktop_Destroy	18
#define LIB_GUI_GUI_Desktop_Draw_Selection 19
#define LIB_GUI_GUI_Desktop_Erase_Sel	20
#define LIB_GUI_GUI_Desktop_Add		21
#define LIB_GUI_GUI_Desktop_Draw	22
#define LIB_GUI_GUI_Desktop_Action	23
#define LIB_GUI_GUI_Desktop_Do		24
#define LIB_GUI_GUI_Image_Create	25
#define LIB_GUI_GUI_Image_Draw		26
#define LIB_GUI_GUI_Image_Erase		27
#define LIB_GUI_GUI_Menubar_Do		28
#define LIB_GUI_GUI_Desktop_Prep	29
#define LIB_GUI_GUI_Desktop_Create_From_Serialized_Data 30
#define LIB_GUI_GUI_Serial_Create	31

extern GUI_Widget* GUI_Popup_Create(byte x, byte y, bool enabled, char* text, byte ID);
extern void GUI_Popup_Add(GUI_Widget* p, GUI_Widget* w);
extern byte GUI_Popup_Do(GUI_Widget* w) ;
extern GUI_Widget* GUI_Menubar_Create(void* callback);
extern void GUI_Menubar_Add(GUI_Widget* menubar, GUI_Widget* w);
extern char GUI_Menubar_Do(GUI_Widget* w) ;
extern GUI_Widget* GUI_Image_Create(byte x, byte y, byte* data, byte height/*, byte width*/);
extern void GUI_Image_Draw(GUI_Widget* w);
extern void GUI_Image_Erase(GUI_Widget* w);
extern GUI_Widget* GUI_Radio_Create(byte x, byte y, byte group, bool toggled);
extern void GUI_Radio_Draw(GUI_Widget* w);
extern void GUI_Radio_Erase(GUI_Widget* w);
extern GUI_Widget* GUI_Checkbox_Create(byte x, byte y, bool checked);
extern void GUI_Checkbox_Draw(GUI_Widget* w);
extern void GUI_Checkbox_Erase(GUI_Widget* w);
extern GUI_Widget* GUI_Label_Create(byte x, byte y, char* text);
extern void GUI_Label_Draw(GUI_Widget* c);
extern void GUI_Label_Erase(GUI_Widget* c);
extern GUI_Widget* GUI_Button_Create(byte x, byte y, byte size, char* text);
extern void GUI_Button_Draw(GUI_Widget* c);
extern void GUI_Button_Erase(GUI_Widget* c);
extern GUI_Container* GUI_Desktop_Create();
extern void GUI_Desktop_Destroy(GUI_Container *c);
extern void GUI_Desktop_Draw_Selection(byte x1, byte y1, byte x2, byte y2);
extern void GUI_Desktop_Erase_Sel(byte x1, byte y1, byte x2, byte y2);
extern bool GUI_Desktop_Add(GUI_Container* c, GUI_Widget* w);
extern void GUI_Desktop_Draw(GUI_Container* c);
extern void GUI_Desktop_Action(GUI_Container* c, GUI_Key key, GUI_Return* r);
extern void GUI_Desktop_Do(GUI_Container* c, GUI_Return* r);
extern void GUI_Desktop_Prep(GUI_Container *c);
extern GUI_Widget* GUI_Textbox_Create(byte x, byte y, byte width, byte size);
extern void GUI_Textbox_Destroy(GUI_Widget *w);
extern void GUI_Textbox_Erase(GUI_Widget *w);
extern void GUI_Textbox_Draw(GUI_Widget* w);
extern byte GUI_Textbox_Do(GUI_Widget *w);

// CUSTOM HELPER FUNCTIONS
extern byte _find_text(serial_text *a, byte s, byte id);
extern byte _find_cb(serial_cb *a, byte s, byte id);
extern GUI_Container* GUI_Serial_Create(serial_cb *a, byte sizeA,
                                 serial_text *b, byte sizeB,
                                 serial_widget *c, byte sizeC,
				 serial_text **reloc);
extern void GUI_Serial_Destroy(GUI_Container *desktop, 
			       serial_text *text, 
			       byte sizeText);
extern void GUI_Desktop_Do_With_Callbacks(GUI_Container *c);
/*
#include "global.h"
#define LIB_GUI 3

#define LIB_GUI_GUI_Popup_Create 	0
#define LIB_GUI_GUI_Popup_Add		1
#define LIB_GUI_GUI_Popup_Do		2
#define LIB_GUI_GUI_Menubar_Create	3
#define LIB_GUI_GUI_Menubar_Add		4
#define LIB_GUI_GUI_Radio_Create	5
#define LIB_GUI_GUI_Radio_Draw		6
#define LIB_GUI_GUI_Radio_Erase		7
#define LIB_GUI_GUI_Checkbox_Create	8
#define LIB_GUI_GUI_Checkbox_Draw	9
#define LIB_GUI_GUI_Checkbox_Erase	10
#define LIB_GUI_GUI_Label_Create	11
#define LIB_GUI_GUI_Label_Draw		12
#define LIB_GUI_GUI_Label_Erase		13
#define LIB_GUI_GUI_Button_Create	14
#define LIB_GUI_GUI_Button_Draw		15
#define LIB_GUI_GUI_Button_Erase	16
#define LIB_GUI_GUI_Desktop_Create	17
#define LIB_GUI_GUI_Desktop_Destroy	18
#define LIB_GUI_GUI_Desktop_Draw_Selection 19
#define LIB_GUI_GUI_Desktop_Erase_Sel	20
#define LIB_GUI_GUI_Desktop_Add		21
#define LIB_GUI_GUI_Desktop_Draw	22
#define LIB_GUI_GUI_Desktop_Action	23
#define LIB_GUI_GUI_Desktop_Do		24
#define LIB_GUI_GUI_Image_Create	25
#define LIB_GUI_GUI_Image_Draw		26
#define LIB_GUI_GUI_Image_Erase		27
#define LIB_GUI_GUI_Menubar_Do		28
#define LIB_GUI_GUI_Desktop_Prep	29
#define LIB_GUI_GUI_Desktop_Create_From_Serialized_Data 30

GUI_Widget* GUI_Popup_Create(byte x, byte y, bool enabled, char* text, byte ID) 
{
  // return, ......
  // return, return, xxx, page, id, id, ....
  sys_execLibf(LIB_GUI, LIB_GUI_GUI_Popup_Create, (byte)x, (byte)y, (bool)enabled, (char*)text, (byte)ID);
}
void GUI_Popup_Add(GUI_Widget* p, GUI_Widget* w)
{
  sys_execLibf(LIB_GUI, LIB_GUI_GUI_Popup_Add, p,w);
}
byte GUI_Popup_Do(GUI_Widget* w) 
{
  sys_execLibf(LIB_GUI, LIB_GUI_GUI_Popup_Do, w);
}
GUI_Widget* GUI_Menubar_Create(void* callback)
{
  sys_execLibf(LIB_GUI, LIB_GUI_GUI_Menubar_Create, callback);
}
void GUI_Menubar_Add(GUI_Widget* menubar, GUI_Widget* w) 
{
  sys_execLibf(LIB_GUI, LIB_GUI_GUI_Menubar_Add, menubar, w);
}
char GUI_Menubar_Do(GUI_Widget* w) 
{
  sys_execLibf(LIB_GUI, LIB_GUI_GUI_Menubar_Do, w);
}
GUI_Widget* GUI_Image_Create(byte x, byte y, byte* data, byte height)
{
  sys_execLibf(LIB_GUI, LIB_GUI_GUI_Image_Create, x,y,data,height);
}
void GUI_Image_Draw(GUI_Widget* w)
{
  sys_execLibf(LIB_GUI, LIB_GUI_GUI_Image_Draw, w);
}
void GUI_Image_Erase(GUI_Widget* w)
{
  sys_execLibf(LIB_GUI, LIB_GUI_GUI_Image_Erase, w);
}
GUI_Widget* GUI_Radio_Create(byte x, byte y, byte group, bool toggled)
{
  sys_execLibf(LIB_GUI, LIB_GUI_GUI_Radio_Create, x,y,group,toggled);
}
void GUI_Radio_Draw(GUI_Widget* w)
{
  sys_execLibf(LIB_GUI, LIB_GUI_GUI_Radio_Draw, w);
}
void GUI_Radio_Erase(GUI_Widget* w)
{
  sys_execLibf(LIB_GUI, LIB_GUI_GUI_Radio_Erase, w);
}
GUI_Widget* GUI_Checkbox_Create(byte x, byte y, bool checked)
{
  sys_execLibf(LIB_GUI, LIB_GUI_GUI_Checkbox_Create, x,y,checked);
}
void GUI_Checkbox_Draw(GUI_Widget* w)
{
  sys_execLibf(LIB_GUI, LIB_GUI_GUI_Checkbox_Draw, w);
}
void GUI_Checkbox_Erase(GUI_Widget* w)
{
  sys_execLibf(LIB_GUI, LIB_GUI_GUI_Checkbox_Erase, w);
}
GUI_Widget* GUI_Label_Create(byte x, byte y, char* text)
{
  sys_execLibf(LIB_GUI, LIB_GUI_GUI_Label_Create, (byte)x,(byte)y,(char*)text);
}
void GUI_Label_Draw(GUI_Widget* c)
{
  sys_execLibf(LIB_GUI, LIB_GUI_GUI_Label_Draw, c);
}
void GUI_Label_Erase(GUI_Widget* c)
{
  sys_execLibf(LIB_GUI, LIB_GUI_GUI_Label_Erase, c);
}
GUI_Widget* GUI_Button_Create(byte x, byte y, byte size, char* text)
{
  sys_execLibf(LIB_GUI, LIB_GUI_GUI_Button_Create, (byte)x,(byte)y,(byte)size,(char*)text);
}
void GUI_Button_Draw(GUI_Widget* c)
{
  sys_execLibf(LIB_GUI, LIB_GUI_GUI_Button_Draw, c);
}
void GUI_Button_Erase(GUI_Widget* c)
{
  sys_execLibf(LIB_GUI, LIB_GUI_GUI_Button_Erase, c);
}
GUI_Container* GUI_Desktop_Create()
{
  sys_execLibf(LIB_GUI, LIB_GUI_GUI_Desktop_Create);
}
void GUI_Desktop_Destroy(GUI_Container *c)
{
  sys_execLibf(LIB_GUI, LIB_GUI_GUI_Desktop_Destroy, c);
}
void GUI_Desktop_Draw_Selection(byte x1, byte y1, byte x2, byte y2)
{
  sys_execLibf(LIB_GUI, LIB_GUI_GUI_Desktop_Draw_Selection,x1,y1,x2,y2 );
}
void GUI_Desktop_Erase_Sel(byte x1, byte y1, byte x2, byte y2)
{
  sys_execLibf(LIB_GUI, LIB_GUI_GUI_Desktop_Erase_Sel,x1,y1,x2,y2 );
}
bool GUI_Desktop_Add(GUI_Container* c, GUI_Widget* w)
{
  sys_execLibf(LIB_GUI, LIB_GUI_GUI_Desktop_Add, c,w);
}
void GUI_Desktop_Draw(GUI_Container* c)
{
  sys_execLibf(LIB_GUI, LIB_GUI_GUI_Desktop_Draw, c);
}
void GUI_Desktop_Action(GUI_Container* c, GUI_Key key, GUI_Return* r)
{
  sys_execLibf(LIB_GUI, LIB_GUI_GUI_Desktop_Action, c,key,r);
}
void GUI_Desktop_Do(GUI_Container* c, GUI_Return* r)
{
  sys_execLibf(LIB_GUI, LIB_GUI_GUI_Desktop_Do, c, r);
}
void GUI_Desktop_Prep(GUI_Container *c)
{
  sys_execLibf(LIB_GUI, LIB_GUI_GUI_Desktop_Prep, c);
}
GUI_Container* GUI_Desktop_Create_From_Serialized_Data(GUI_Serial_Data** ser)
{
  sys_execLibf(LIB_GUI, LIB_GUI_GUI_Desktop_Create_From_Serialized_Data, ser);
}

// CUSTOM HELPER FUNCTIONS

typedef struct
{
  byte ID;
  void* callback;
} serial_cb;
typedef struct
{
  byte ID;
  char* text;
} serial_text;
typedef struct
{
  byte id;
  GUI_Widget_Type type;
  byte parent;
  byte x1, y1, x2, y2, textID, parentID, callbackID, extra1, extra2;
} serial_widget;

byte _find_text(serial_text *a, byte s, byte id)
{
  byte i;
  
  for(i = 0; i < s; i++)
  {
    if(a[i].ID == id)
      return i;
  }
  return 0;
}
byte _find_cb(serial_cb *a, byte s, byte id)
{
  byte i;
  
  for(i = 0; i < s; i++)
  {
    if(a[i].ID == id)
      return i;
  }
  return 0;
}
GUI_Container* GUI_Serial_Create(serial_cb *a, byte sizeA,
                                 serial_text *b, byte sizeB,
                                 serial_widget *c, byte sizeC)
{
  GUI_Container *desktop = GUI_Desktop_Create();
  byte i;
  GUI_Widget *w;
  
  for(i = 0; i < sizeC; i++)
  {
    switch(c[i].type)
    {
      case Label:
	w = GUI_Label_Create(c[i].x1, c[i].y1, b[_find_text(b,sizeB,c[i].textID)].text);
	break;
      case Button:
	w = GUI_Button_Create(c[i].x1, c[i].y1, c[i].x2, b[_find_text(b,sizeB,c[i].textID)].text);
	if(c[i].callbackID)
	  w->callback = a[_find_cb(a,sizeA,c[i].callbackID)].callback;
	break;
      case Checkbox:
	w = GUI_Checkbox_Create(c[i].x1, c[i].y1, c[i].extra1);
	w->callback = a[_find_cb(a,sizeA,c[i].callbackID)].callback;
	break;
      case Radio:
	w = GUI_Radio_Create(c[i].x1, c[i].y1, c[i].extra1, c[i].extra2);
	w->callback = a[_find_cb(a,sizeA,c[i].callbackID)].callback;
	break;
    }
    
    GUI_Desktop_Add(desktop, w);
  }
  GUI_Desktop_Prep(desktop);
  return desktop;
}

void GUI_Desktop_Do_With_Callbacks(GUI_Container *c)
{
  GUI_Return *ret = malloc(sizeof(GUI_Return));
  
  ret->w = 1;
  
  while(ret->w != 0)
  {
    GUI_Desktop_Do(c, ret);
    if(ret->w)
      ret->w->callback(ret->k, ret->c, ret->w);
  }
  
  free(ret);
}
*/
