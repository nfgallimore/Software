 // Sample program
#include <global.h>
#include <glassos.h>
#include <binary_header.h>

DEFINE_AUTHOR("Sample")
DEFINE_NAME("Hello World")

void main()
{
  LCD_clear();
  puts("Hello World!");
  getchar();
  return;
}
