 
#!/bin/sh
if [ ! -x hex2bin ]
then
  echo "You are missing hex2bin, downloading..."
  wget "http://superb-dca2.dl.sourceforge.net/project/hex2bin/hex2bin/Hex2bin-1.0.9.tar.bz2"
  tar xjf Hex2bin-1.0.9.tar.bz2
  cp Hex2bin-1.0.9/hex2bin .
  chmod +x hex2bin
  rm Hex2bin-1.0.9.tar.bz2
  rm -r Hex2bin-1.0.9
fi
