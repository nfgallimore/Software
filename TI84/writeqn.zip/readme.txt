WRITEQN 83/83+
By John Pescatore (jdp1@crosswinds.net)

Description: This program will find the equation of an either a linear or quadratic function.  This program comes very useful in Algebra.

Instructions: Send group entitled WRITEQN to your calculator and run the program WRITEQN it will display a menu:
	2 points- enter 2 points and it will give you the linear equation
	1 pt and slope- enter 1 point and the slope of the line and it will give you the equation
	3 points- enter 3 points of a parabola and it will give you the equation
	Vertex and 1 point- enter the vertex (Vx1, Vy1) and 1 other point of the parabola and it will give you the equation of it.

Note: program GRAPH is necessary for this program it sets your graph screen to the default setting, it clears the graph screen of any drawing and deletes any graphs.

Version- 1.0 First version 
no known bugs if any found please e-mail me a jdp1@crosswinds.net

Distribution: feel free to distribute but please keep my name on the program and if distributing the zip file keep the readme file intact.

Website- you can visit my website a http://beans1.cjb.net its not calculator related but its still worth a visit.

Enjoy 
John Pescatore

