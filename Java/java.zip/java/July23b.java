import java.util.Date;

class July23b
{
     public static void main (String [] args)
     {
         Date today = new Date();

         System.out.println (today);
         System.out.printf ("Today is ... %ta, %tB \n", today, today);
     }
}     

