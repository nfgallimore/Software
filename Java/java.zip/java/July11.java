class July11
{
   public static void main (String [] args)
   { 
        double d1 = 0.25 + 0.10 + 0.05 + 0.01;
        double d2 = 0.01 + 0.05 + 0.10 + 0.25;
 
        System.out.println ("Value of d1 = " + d1);
        System.out.println ("Value of d2 = " + d2);
   }
}
