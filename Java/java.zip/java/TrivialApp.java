/*  This is file TrivialApp.java
    (A trivial application that displays a string)
    Compile this by typing       % javac TrivialApp.java
    Run the program by typing    % java TrivialApp
*/

class TrivialApp 
{
    public static void main ( String [] args) 
    {
       System.out.println ( "I really  REALLY \nmiss Scratch! " );
       System.out.println ("She said: \"Get lost, knucklehead!\" ");
    }

}
