#include <stdio.h>

typedef struct node
{

	(void*) data;
	node* next;

} node;

void func(student* s)
{
	// to do
}
func(&s1)

student* s = malloc(sizeof(student));
s->age = 4;

struct b;
struct a
{
	struct b *x;
};
struct b
{
	struct a *y;
};