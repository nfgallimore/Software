class Dog
{
    // instance variables
    // provide the "state" 
    String name;
    double weight;
    int age;
    boolean hungry;

    void speak ()
    {
        System.out.println ("WOOF!");
    }
}    


