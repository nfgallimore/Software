class July16
{
    public static void main (String [] args)
    {
        int a = 0;
        int b = 0;

        System.out.println (++a);
        System.out.println (b++);

        System.out.println ("Final value of a = " + a +
                             ", and the final value of b = " + b);
        int c, d;
        d = c= b= a = 17;
    }
}    
