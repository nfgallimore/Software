// comments at the beginning
class June30
{
   public static void main ( String [] args )
   {
      System.out.println( "I am already missing JKarel!");
      System.out.println(" how about you??? ");
   }
}
