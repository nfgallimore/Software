class Student extends Person
{
    private int grade;
    private String schoolName;

    // YOU WILL NEED TO WRITE THIS CLASS!!
}
