// SuperDemo.java
/** @author:  Henry H. Leitner
  * @version: Last modified on January 23, 2006
  * Uses class C to demonstrate the use of "this" 
  * and "super" constructors
  */

class SuperDemo
{
   public static void main (String args[])
   {
       C anObjectOfTypeC = new C();
   }
}
