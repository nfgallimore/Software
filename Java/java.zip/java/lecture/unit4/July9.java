// import java.util.*;

class July9
{
  public static void main (String [] args)
  {
      java.util.Date today = new java.util.Date();
      System.out.println (today);
      System.out.printf ("Today is ... %ta %tB %td %tr \n", today,
                           today, today, today);
  }
}

