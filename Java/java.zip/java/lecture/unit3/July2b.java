class July2b
{
    public static void main (String [] args)
    {
         int a = 0;
         int b = 0;

         System.out.println  ( ++a );
         System.out.println  ( b++ );

         System.out.println ("final a = " + a + ", and final b = " + b);

         int c = 17;

          a = b = c = 17;
     }
}
