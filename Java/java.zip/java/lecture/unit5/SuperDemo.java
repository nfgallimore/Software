// SuperDemo.java
/** @author:  Henry H. Leitner
  * @version: Last modified on July 5, 2013
  * Uses class C to demonstrate the use of "this" 
  * and "super" constructors
  */

class SuperDemo
{
   public static void main (String [] args)
   {
       C anObjectOfTypeC = new C ();
   }
}
