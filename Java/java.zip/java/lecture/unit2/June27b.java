class June27b
{
    public static void drawOneBox()
    {
        System.out.println ("+-------------------+");
        System.out.println ("|                   |");
        System.out.println ("|                   |");
        System.out.println ("|                   |");
        System.out.println ("|                   |");
        System.out.println ("|                   |");
        System.out.println ("|                   |");
        System.out.println ("+-------------------+");
    }

    public static void main (String [] args)
    {
        int i;
        i = 3 + 4 * 5;
        System.out.println ( i );
        drawOneBox();
        System.out.println ("\n\n");
        drawOneBox();
        System.out.println ("\n\n");
        drawOneBox();
        System.out.println ("\n\n");
    }

}


