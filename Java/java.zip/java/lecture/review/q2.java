class q2
{
    public static void main(String[] args) {
	for(int k = 0; k < 20; k+= 2)
	    for(int j = 0; j < 5; j++) {
		System.out.print("*");
	    }
    }
}
