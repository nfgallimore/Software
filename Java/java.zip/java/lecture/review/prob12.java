class prob12
{
    public static void main(String[] args) {
    
	int [] array = {1, 4, 1, 5, 9};
	
    }
    public static int[] partial Sum (int [] arr) {
	int [] sum = new int [arr.length];
	for(int j = 0; j < sum.length; j++)
	    sum[j] = 0;

	sum[0] = arr[0];

    }
}
