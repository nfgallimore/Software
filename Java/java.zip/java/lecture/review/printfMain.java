class printfMain
{
    public static void main(String args [])
    {
        int x=1;
        float y=3.0f;
        double z=10.0;
        char c='a';


        System.out.printf("x = %d, y = %05.2f," + " z = %05.2f, c=%c \t \n",x,y,z,c);
    
    }
}
