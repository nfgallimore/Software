6.7           This file has
           several input lines.

10        20                30                             40

test
