class July2b
{

   public static void main (String [] args)
   {
        drawOneBox();
        System.out.println  ("\n\n");
        drawOneBox();
        System.out.println  ("\n\n");
        drawOneBox();
        System.out.println  ("\n\n");
   }


   static void drawOneBox ()
   {
        System.out.println ("+-------------------+");
        System.out.println ("|                   |");
        System.out.println ("|                   |");
        System.out.println ("|                   |");
        System.out.println ("|                   |");
        System.out.println ("|                   |");
        System.out.println ("|                   |");
        System.out.println ("|                   |");
        System.out.println ("+-------------------+");
    }
}
